package com.cgi.ec.cacsConsumer;

import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;
import org.springframework.context.annotation.ComponentScan;


@SpringBootApplication
@ComponentScan(basePackages= {"com.cacs"})
public class CacsSpringConsumerApplication {

	Logger log =LoggerFactory.getLogger(CacsSpringConsumerApplication.class);
	
	public static void main(String[] args) {
		SpringApplication.run(CacsSpringConsumerApplication.class, args);
	}

	
}
