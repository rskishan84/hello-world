package com.cacs.spring.streams;

import java.util.function.Consumer;

import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.context.annotation.Bean;
import org.springframework.context.annotation.Configuration;
import org.springframework.integration.IntegrationMessageHeaderAccessor;
import org.springframework.messaging.Message;


@Configuration
public class ConsumerService{
	
	Logger log =LoggerFactory.getLogger(ConsumerService.class);
	
	@Bean
	public Consumer<Message<FinancialExtract>> get(){
		return  finExt->{
			Object correlationId = finExt.getHeaders().get(IntegrationMessageHeaderAccessor.CORRELATION_ID);
			log.info("****************************** Consumer get(): correlation: {}", correlationId);
			log.info("Recieved Message: {}",finExt.getPayload());
		};
	}
	
	@Bean
	public Consumer<Message<FinancialExtract>> getTest(){
		return  finExt->{
			Object correlationId = finExt.getHeaders().get(IntegrationMessageHeaderAccessor.CORRELATION_ID);
			log.info("****************************** Consumer getTest(): correlation: {}", correlationId);
			log.info("Recieved Message in wrong Consumer: {}",finExt.getPayload());
		};
	}
	
}
	
