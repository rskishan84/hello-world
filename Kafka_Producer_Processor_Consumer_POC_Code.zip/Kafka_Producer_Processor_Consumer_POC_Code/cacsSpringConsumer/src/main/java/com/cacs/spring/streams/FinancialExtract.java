package com.cacs.spring.streams;

import lombok.AllArgsConstructor;
import lombok.Data;
import lombok.NoArgsConstructor;

@Data
@AllArgsConstructor
@NoArgsConstructor
public class FinancialExtract {
	
	public String accountNumber;
	public String locationCode;
	public String guid;
	
}
