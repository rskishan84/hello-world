package com.cgi.ec.cacsConsumer;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class CacsSpringConsumerApplicationTests {

	@Test
	void contextLoads() {
	}

}
