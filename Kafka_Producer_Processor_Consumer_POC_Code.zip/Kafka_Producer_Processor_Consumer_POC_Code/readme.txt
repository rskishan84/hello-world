Please follow below steps to setup and run Proof of concept code,

1. Import these three gradle projects into your workspace.
2. Build all three projects using gradlw clean build.
3. Start the zookeeper and kafka service by following kafka setup and installation confluence link.
4. Run the cacsSpringProducer spring boot application to publish data into kafka instance.
5. Run the cacsSpringProcessor spring boot application to process the produced data.
6. Run the cacsSpringConsumer to consume data from the processor.
