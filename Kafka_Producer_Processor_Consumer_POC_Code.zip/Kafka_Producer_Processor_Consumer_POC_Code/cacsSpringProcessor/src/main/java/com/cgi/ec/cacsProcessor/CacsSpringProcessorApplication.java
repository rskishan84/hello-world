package com.cgi.ec.cacsProcessor;

import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;
import org.springframework.context.annotation.ComponentScan;

@SpringBootApplication
@ComponentScan(basePackages= {"com.cacs"})
public class CacsSpringProcessorApplication {

	Logger log = LoggerFactory.getLogger(CacsSpringProcessorApplication.class);
	
	public static void main(String[] args) {
		SpringApplication.run(CacsSpringProcessorApplication.class, args);
	}
}
