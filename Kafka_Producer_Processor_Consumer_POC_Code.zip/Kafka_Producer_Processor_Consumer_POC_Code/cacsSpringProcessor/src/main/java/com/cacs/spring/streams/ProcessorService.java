package com.cacs.spring.streams;

import java.util.function.Function;

import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.context.annotation.Bean;
import org.springframework.context.annotation.Configuration;
import org.springframework.integration.IntegrationMessageHeaderAccessor;
import org.springframework.messaging.Message;


@Configuration
public class ProcessorService {

	Logger log = LoggerFactory.getLogger(ProcessorService.class);

	@Bean
	public Function<Message<FinancialExtract>, FinancialExtract> transform() {
		String append = "CACS";

		return finExt -> {
			Object correlationId = finExt.getHeaders().get(IntegrationMessageHeaderAccessor.CORRELATION_ID);
			log.info("****************************** Processor transform() correlation: {}", correlationId);

			FinancialExtract fin = finExt.getPayload();
			fin.setAccountNumber(append + fin.getAccountNumber());
			log.info("Processed message:{}", fin.getAccountNumber());
			return fin;
			//MessageBuilder.withPayload(fin).setHeader("dataType", "processed").setHeader(IntegrationMessageHeaderAccessor.CORRELATION_ID, correlationId).build();
		};
	}

}
