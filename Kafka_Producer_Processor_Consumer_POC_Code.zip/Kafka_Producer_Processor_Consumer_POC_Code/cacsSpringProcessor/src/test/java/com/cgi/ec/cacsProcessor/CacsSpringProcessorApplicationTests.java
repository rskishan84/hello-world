package com.cgi.ec.cacsProcessor;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class CacsSpringProcessorApplicationTests {

	@Test
	void contextLoads() {
	}

}
