package com.cgi.ec.producer;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class CacsSpringProducerApplicationTests {

	@Test
	void contextLoads() {
	}

}
