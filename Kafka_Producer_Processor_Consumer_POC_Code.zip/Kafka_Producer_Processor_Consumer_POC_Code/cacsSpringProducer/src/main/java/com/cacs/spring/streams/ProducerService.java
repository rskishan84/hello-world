package com.cacs.spring.streams;

import java.util.function.Supplier;

import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.context.annotation.Bean;
import org.springframework.context.annotation.Configuration;
import org.springframework.integration.IntegrationMessageHeaderAccessor;
import org.springframework.messaging.Message;
import org.springframework.messaging.support.MessageBuilder;

@Configuration
public class ProducerService {
	Logger log = LoggerFactory.getLogger(ProducerService.class);

	@Bean
	public Supplier<Message<FinancialExtract>> send() {
		
		return () -> { 
			FinancialExtract financialExtract = new FinancialExtract("20010", "411132", "30ddc78457364");
			log.info("************Sent Message: AcctNo:" + financialExtract.accountNumber + " Location Code: "
					+ financialExtract.locationCode + " Guid: " + financialExtract.guid);

			Message<FinancialExtract> fin = MessageBuilder.withPayload(financialExtract).setHeader(IntegrationMessageHeaderAccessor.
					CORRELATION_ID, java.util.UUID.randomUUID())
					.build();
			
			Object correlationId = fin.getHeaders().get(IntegrationMessageHeaderAccessor.CORRELATION_ID);
			log.info("****************************** Producer send(): correlation: {}", correlationId);
			return fin;
		};
	}

}
