package com.cgi.ec.producer;


import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;
import org.springframework.context.annotation.ComponentScan;

@SpringBootApplication
@ComponentScan(basePackages= {"com.cacs"})
public class CacsSpringProducerApplication {

	Logger log = LoggerFactory.getLogger(CacsSpringProducerApplication.class);
	
	public static void main(String[] args) {
		SpringApplication.run(CacsSpringProducerApplication.class, args);
	}

	
}
