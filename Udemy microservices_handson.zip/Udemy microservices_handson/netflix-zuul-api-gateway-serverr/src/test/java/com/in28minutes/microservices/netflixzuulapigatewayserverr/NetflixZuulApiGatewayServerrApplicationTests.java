package com.in28minutes.microservices.netflixzuulapigatewayserverr;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class NetflixZuulApiGatewayServerrApplicationTests {

	@Test
	void contextLoads() {
	}

}
