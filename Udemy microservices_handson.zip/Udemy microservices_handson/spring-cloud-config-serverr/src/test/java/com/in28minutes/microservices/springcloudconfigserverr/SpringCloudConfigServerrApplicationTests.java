package com.in28minutes.microservices.springcloudconfigserverr;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class SpringCloudConfigServerrApplicationTests {

	@Test
	void contextLoads() {
	}

}
