package com.in28minutes.microservices.currencyexchangeservicee;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;
import org.springframework.cloud.client.discovery.EnableDiscoveryClient;
import org.springframework.context.annotation.Bean;

import com.in28minutes.microservices.netflixzuulapigatewayserverr.Sampler;

@SpringBootApplication
@EnableDiscoveryClient
public class CurrencyExchangeServiceeApplication {

	public static void main(String[] args) {
		SpringApplication.run(CurrencyExchangeServiceeApplication.class, args);
	}
	
	@Bean
	public Sampler defaultSampler() {
		return  Sampler.ALWAYS_SAMPLER;
	}

}
