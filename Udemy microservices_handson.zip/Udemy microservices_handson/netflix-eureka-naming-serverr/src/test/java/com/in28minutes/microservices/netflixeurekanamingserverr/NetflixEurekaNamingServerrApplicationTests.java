package com.in28minutes.microservices.netflixeurekanamingserverr;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class NetflixEurekaNamingServerrApplicationTests {

	@Test
	void contextLoads() {
	}

}
