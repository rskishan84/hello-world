package com.in28minutes.rest.webservices.restfulwebservicess;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class RestfulWebServicessApplicationTests {

	@Test
	void contextLoads() {
	}

}
