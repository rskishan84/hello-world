/** $disclosureStatement$ */
package com.cgi.ec.restful.controller;

import java.sql.Timestamp;
import java.time.LocalDate;
import java.util.ArrayList;
import java.util.Arrays;
import java.util.List;
import java.util.Objects;
import java.util.Set;
import java.util.stream.Collectors;

import javax.validation.ConstraintViolation;
import javax.validation.ConstraintViolationException;
import javax.validation.Valid;
import javax.validation.Validator;

import org.modelmapper.ModelMapper;
import org.slf4j.ext.XLogger;
import org.slf4j.ext.XLoggerFactory;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.MediaType;
import org.springframework.util.Assert;
import org.springframework.web.bind.annotation.DeleteMapping;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PatchMapping;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.PutMapping;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RestController;

import com.ams.core.service.ServiceFactory;
import com.ams.core.util.DomainObjectFactory;
import com.cgi.c360.exception.C360Exception;
import com.cgi.c360.exception.C360RuntimeException;
import com.cgi.c360.exception.C360ValidationException;
import com.cgi.ec.business.util.BcmProcessingUtils;
import com.cgi.ec.common.util.BCMConstants;
import com.cgi.ec.common.util.ProblemNumbers;
import com.cgi.ec.domain.api.AddContactDebtor;
import com.cgi.ec.domain.api.CaseAccountDetails;
import com.cgi.ec.domain.bcm.BankruptcyCase;
import com.cgi.ec.domain.bcm.BankruptcyPlan;
import com.cgi.ec.domain.bcm.CaseAccount;
import com.cgi.ec.domain.bcm.CaseAccountContact;
import com.cgi.ec.domain.bcm.CaseDebtor;
import com.cgi.ec.domain.bcm.ContactDebtor;
import com.cgi.ec.domain.bcm.PetitionBalance;
import com.cgi.ec.domain.bcm.ProofOfClaim;
import com.cgi.ec.domain.bcm.action.BankruptcyCaseAccountAction;
import com.cgi.ec.domain.bcm.action.BankruptcyCaseAction;
import com.cgi.ec.domain.bcm.payment.BankruptcyPaymentTransaction;
import com.cgi.ec.domain.util.BooleanObj;
import com.cgi.ec.restful.dto.StatusResponseDTO;
import com.cgi.ec.restful.dto.bcm.AddCaseDebtorDTO;
import com.cgi.ec.restful.dto.bcm.AssociateAccountDTO;
import com.cgi.ec.restful.dto.bcm.AssociateCaseAccountDTO;
import com.cgi.ec.restful.dto.bcm.BankruptcyCaseAccountActionDTO;
import com.cgi.ec.restful.dto.bcm.BankruptcyCaseActionDTO;
import com.cgi.ec.restful.dto.bcm.BankruptcyCaseDTO;
import com.cgi.ec.restful.dto.bcm.BankruptcyCaseRetrievalDTO;
import com.cgi.ec.restful.dto.bcm.BankruptcyPlanDTO;
import com.cgi.ec.restful.dto.bcm.CaseAccountActionAddressDTO;
import com.cgi.ec.restful.dto.bcm.CaseAccountContactDTO;
import com.cgi.ec.restful.dto.bcm.CaseAccountDTO;
import com.cgi.ec.restful.dto.bcm.CaseDebtorDTO;
import com.cgi.ec.restful.dto.bcm.PetitionBalanceDTO;
import com.cgi.ec.restful.dto.bcm.PostTransactionDTO;
import com.cgi.ec.restful.dto.bcm.ProofOfClaimDTO;
import com.cgi.ec.restful.dto.bcm.UpdateBankruptcyCaseDTO;
import com.cgi.ec.service.api.BankruptcyPaymentTransService;
import com.cgi.ec.service.api.BcmMgmtService;
import com.cgi.ec.service.api.CaseActionService;
import com.cgi.ec.util.ErrorUtil;
import com.cgi.eci.common.problem.ProblemUtil;
import com.cgi.eci.common.util.Parameter;
import com.cgi.eci.common.util.ServiceUtils;
import com.cgi.eci.domain.Problem;
import com.cgi.eci.domain.util.StringObj;
import com.fasterxml.jackson.core.JsonProcessingException;
import com.fasterxml.jackson.databind.JsonNode;
import com.fasterxml.jackson.databind.ObjectMapper;
import com.github.fge.jsonpatch.JsonPatch;
import com.github.fge.jsonpatch.JsonPatchException;

import io.swagger.v3.oas.annotations.Operation;
import io.swagger.v3.oas.annotations.responses.ApiResponse;
import io.swagger.v3.oas.annotations.responses.ApiResponses;

@RestController
@RequestMapping(value = { "/rs/bcm" })
public class BcmRestController {
	
	private static final XLogger LOG = XLoggerFactory.getXLogger(BcmRestController.class);
	
	private static final String LOG_INVALID_CASE_ID = "caseID is invalid";
	private static final String LOG_INVALID_LOCATION_CODE = "Location Code is invalid";
	private static final String LOG_INVALID_ACCOUNT_NUMBER = "Account Number is Invalid";
	private static final String LOG_CASE_ID_NULL = "CaseID is Null";
	private static final String LOG_INVALID_TRANSACTION_CODE = "Transaction Code is Invalid";
	public static final String LOG_PLAN_MODEL_NULL = "Bankruptcy Plan Model is null.";
	private static final String LOG_INVALID_CLAIM_CREATION_DATE = "Claim creation date is Invalid";
	private static final String LOG_INVALID_PLAN_RECEIVED_DATE = "Plan received date is Invalid";
	private static final String SPACE = " ";
 
	@Autowired
	ModelMapper modelMapper;
	
	@Autowired
	ObjectMapper objectMapper;

	@Autowired
	Validator validator;
	
	/**
	 * returns Bankruptcy Case and Case Related Details.
	 *
	 * @param caseID the case ID
	 * @return BankruptcyCaseRetrievalDTO
	 */
	@GetMapping(value = "/cases/{caseID}")
	public BankruptcyCaseRetrievalDTO getCaseDetails(@PathVariable(value = "caseID") String caseID) {
		LOG.entry(caseID);
		Assert.notNull(caseID, LOG_CASE_ID_NULL);
		BankruptcyCase bcm = (BankruptcyCase) DomainObjectFactory.getInstance().newObject(BankruptcyCase.CLASS_ID);
		bcm.setCaseID(caseID);
		BcmMgmtService bcmService = (BcmMgmtService) ServiceFactory.getInstance().lookup(BcmMgmtService.LOOKUP_NAME);
		BankruptcyCase bankruptcyCase = bcmService.retrieveCaseDetails(bcm);
		// Create problem message if no records found.
		List<Problem> problemList = bankruptcyCase.getChildren(Problem.CLASS_ID);
		if (!problemList.isEmpty()) {
			LOG.error("Retrieving case details failed with problem(s) for {}", caseID);
			throw new C360ValidationException(ErrorUtil.problemToValidationError(problemList));
		}
		return LOG.exit(BankruptcyCaseRetrievalDTO.of(bankruptcyCase, modelMapper));
	}

	/**
	 * This method is used for insert new balance details record.
	 *
	 * @param petitionBalanceDTO 
	 * @param caseID              
	 * @param locationCode         
	 * @param accountNumber       
	 * @return PetitionBalanceDTO
	 */
	@Operation(summary="Add a new petition balance",
			description="Adds the details of the petition balance for the indicated case and account.")
	@ApiResponses(value = {
		@ApiResponse(responseCode = "200", description = "Petition balance added successfully."),
		@ApiResponse(responseCode = "400", description = "Bad Request")
	})
	@PostMapping(value = "/cases/{caseID}/petition/petitionbalances/{locationCode}/{accountNumber}", consumes = MediaType.APPLICATION_JSON_VALUE, 
	produces = MediaType.APPLICATION_JSON_VALUE)
	public PetitionBalanceDTO addPetitionBalance(@Valid @RequestBody PetitionBalanceDTO petitionBalanceDTO,
			@PathVariable("caseID") String caseID, @PathVariable("locationCode") String locationCode,
			@PathVariable("accountNumber") String accountNumber) {
		LOG.entry(petitionBalanceDTO);
		Assert.notNull(petitionBalanceDTO, "Petition Balance DTO is null");
		Assert.isTrue(caseID.equalsIgnoreCase(petitionBalanceDTO.getCaseID()), LOG_INVALID_CASE_ID);
		Assert.isTrue(locationCode.equalsIgnoreCase(petitionBalanceDTO.getLocationCode()), LOG_INVALID_LOCATION_CODE);
		Assert.isTrue(accountNumber.equalsIgnoreCase(petitionBalanceDTO.getAccountNumber()), LOG_INVALID_ACCOUNT_NUMBER);

		PetitionBalance petitionBal =  PetitionBalanceDTO.toDomain(petitionBalanceDTO, modelMapper);
		BcmMgmtService bcmService = (BcmMgmtService) ServiceFactory.getInstance().lookup(BcmMgmtService.LOOKUP_NAME);
		petitionBal = bcmService.addPetitionBalance(petitionBal);

		List<Problem> problemList = petitionBal.getChildren(Problem.CLASS_ID);
		if (!problemList.isEmpty()) {
			LOG.error("Adding petition balance failed with problem(s) for {}, {}, {}, {}", caseID, locationCode, accountNumber, 
					petitionBalanceDTO.getBalanceIdentifier());
			throw new C360ValidationException(ErrorUtil.problemToValidationError(problemList));
		}
		return LOG.exit(PetitionBalanceDTO.of(petitionBal, modelMapper));
	}

	/**
	 * This method is used for save the balance details.
	 *
	 * @param petitionBalanceDTO 
	 * @param caseID              
	 * @param locationCode        
	 * @param accountNumber       
	 * @param balanceIdentifier          
	 * @return PetitionBalanceDTO
	 */
	@Operation(summary="Update an existing petition balance",
			description="Updates the details of the petition balance for the indicated case, account and identifier with the petition balance provided.")
	@ApiResponses(value = {
		@ApiResponse(responseCode = "200", description = "Petition balance updated successfully."),
		@ApiResponse(responseCode = "400", description = "Bad Request")
	})
	@PutMapping(value = "/cases/{caseID}/petition/petitionbalances/{locationCode}/{accountNumber}/{balanceIdentifier}", 
	consumes = MediaType.APPLICATION_JSON_VALUE, produces = MediaType.APPLICATION_JSON_VALUE)
	public PetitionBalanceDTO updatePetitionBalance(@Valid @RequestBody PetitionBalanceDTO petitionBalanceDTO,
			@PathVariable("caseID") String caseID, @PathVariable("locationCode") String locationCode,
			@PathVariable("accountNumber") String accountNumber, @PathVariable("balanceIdentifier") String balanceIdentifier) {
		LOG.entry(petitionBalanceDTO);
		Assert.notNull(petitionBalanceDTO, "Petition Balance DTO is null");
		Assert.isTrue(caseID.equalsIgnoreCase(petitionBalanceDTO.getCaseID()), LOG_INVALID_CASE_ID);
		Assert.isTrue(locationCode.equalsIgnoreCase(petitionBalanceDTO.getLocationCode()), LOG_INVALID_LOCATION_CODE);
		Assert.isTrue(accountNumber.equalsIgnoreCase(petitionBalanceDTO.getAccountNumber()), LOG_INVALID_ACCOUNT_NUMBER);
		Assert.isTrue(balanceIdentifier.equalsIgnoreCase(petitionBalanceDTO.getBalanceIdentifier()), "Balance Identifier is Invalid");
		
		PetitionBalance petitionBal = PetitionBalanceDTO.toDomain(petitionBalanceDTO, modelMapper);
		BcmMgmtService bcmService = (BcmMgmtService) ServiceFactory.getInstance().lookup(BcmMgmtService.LOOKUP_NAME);
		petitionBal = bcmService.updatePetitionBalance(petitionBal);

		List<Problem> problemList = petitionBal.getChildren(Problem.CLASS_ID);
		if (!problemList.isEmpty()) {
			LOG.error("Updating petition balance failed with problem(s) for {}, {}, {}, {}", caseID, locationCode, accountNumber, 
					petitionBalanceDTO.getBalanceIdentifier());
			throw new C360ValidationException(ErrorUtil.problemToValidationError(problemList));
		}
		return LOG.exit(PetitionBalanceDTO.of(petitionBal, modelMapper));
	}

	/**
	 * posts transaction to case account.
	 *
	 * @param paymentTransModel 
	 * @param caseID  
	 * @param locationCode    
	 * @param accountNumber      
	 * @return StatusResponseDTO
	 */
	@Operation(summary="Posts transaction to case account.",
			description="Posts payment, reversal and excess recovery transaction to bankruptcy case account.")
	@ApiResponses(value = {
		@ApiResponse(responseCode = "200", description = "Post transaction submitted successfully."),
		@ApiResponse(responseCode = "400", description = "Bad Request")
	})
	@PostMapping(value = "/cases/{caseID}/accounts/{locationCode}/{accountNumber}/financialTransactions",  consumes = MediaType.APPLICATION_JSON_VALUE, 
			produces = MediaType.APPLICATION_JSON_VALUE)
	public StatusResponseDTO updatePaymentsWithTransaction(@Valid @RequestBody PostTransactionDTO postTransactionDTO,
			@PathVariable("caseID") String caseID, @PathVariable("locationCode") String locationCode,
			@PathVariable("accountNumber") String accountNumber) {

		LOG.entry(postTransactionDTO);
		Assert.isTrue(caseID.equalsIgnoreCase(postTransactionDTO.getCaseID()), LOG_INVALID_CASE_ID);
		Assert.isTrue(accountNumber.equalsIgnoreCase(postTransactionDTO.getAccountNumber()), LOG_INVALID_ACCOUNT_NUMBER);
		Assert.isTrue(locationCode.equalsIgnoreCase(postTransactionDTO.getLocationCode()), LOG_INVALID_LOCATION_CODE);
		Assert.isTrue(BCMConstants.getTransactionCodeClassIdMap().containsKey(postTransactionDTO.getTransactionCode()), 
				LOG_INVALID_TRANSACTION_CODE);

		BankruptcyPaymentTransService paymentTransService = (BankruptcyPaymentTransService) ServiceFactory.getInstance()
				.lookup(BankruptcyPaymentTransService.LOOKUP_NAME);
		BankruptcyPaymentTransaction paymentTransaction = (BankruptcyPaymentTransaction) postTransactionDTO
				.toDomain(postTransactionDTO, modelMapper);
		
		//Invokes service to process payment transaction
		paymentTransaction = paymentTransService.processBankruptcyPaymentTransaction(paymentTransaction);
		List<Problem> problemList = paymentTransaction.getChildren(Problem.CLASS_ID);
		if (!problemList.isEmpty()) {
			LOG.error("Processing error for payment transaction: {}, {}, {}, {}", caseID, locationCode, accountNumber,
					postTransactionDTO.getTransactionCode());
			throw new C360ValidationException(ErrorUtil.problemToValidationError(problemList));
		}
		return LOG.exit(new StatusResponseDTO(StatusResponseDTO.SUCCESS));
	}

	/**
	 * Updates case and case account with action.
	 *
	 * @param bankruptcyCaseActionDTO 
	 * @param caseID   
	 * @return StatusResponseDTO
	 */
	@Operation(summary = "Update an existing Bankruptcy Case with case action", 
			description = "Updates the details of the Bankruptcy Case with performed action details.")
	@ApiResponses(value = { @ApiResponse(responseCode = "200", description = "Case Action is submitted successfully."),
			@ApiResponse(responseCode = "400", description = "Bad Request") })
	@PostMapping(value = "/cases/{caseID}/action", consumes = MediaType.APPLICATION_JSON_VALUE, produces = MediaType.APPLICATION_JSON_VALUE)
	public StatusResponseDTO updateCaseWithAction(@Valid @RequestBody BankruptcyCaseActionDTO bankruptcyCaseActionDTO,
			@PathVariable("caseID") String caseID) {
		LOG.entry(bankruptcyCaseActionDTO);
		Assert.isTrue(caseID.equalsIgnoreCase(bankruptcyCaseActionDTO.getCaseID()), LOG_INVALID_CASE_ID);
		BankruptcyCaseAction bankruptcyCaseAction = BankruptcyCaseActionDTO.toDomain(bankruptcyCaseActionDTO, modelMapper);
		BooleanObj updatedCaseAction = null;
		List<StringObj> accountGuids = new ArrayList<>();
		StringObj stringObj = null;
		List<CaseAccount> caseAccounts = bankruptcyCaseAction.getCaseAccount();
		for (CaseAccount caseAccount : caseAccounts) {
			caseAccount.setCaseID(caseID);
			String caseAccountGuid = ServiceUtils.lookupPKByBK(caseAccount);
			if (caseAccountGuid == null) {
				LOG.error("case account not found while update for: {}, {}, {}, {}", caseID, caseAccount.getLocationCode(), 
						caseAccount.getAccountNumber());
				Problem problem = (Problem) DomainObjectFactory.getInstance().newObject(Problem.CLASS_ID);
				problem.setErrorSymbol(ProblemNumbers.MSG_NO_RECORDS);
				problem.setDescription("No Case Account Records returned for caseID: " + caseID + " Location Code: " + caseAccount.getLocationCode() +
						" and Account Number: " + caseAccount.getAccountNumber());
				List<Problem> problemList = new ArrayList<>();
				problemList.add(problem);
				throw new C360ValidationException(ErrorUtil.problemToValidationError(problemList));
			}
			stringObj = (StringObj) DomainObjectFactory.getInstance().newObject(StringObj.CLASS_ID);
			stringObj.setData(caseAccountGuid);

			// Add the account guid into list
			accountGuids.add(stringObj);
		}

		// Remove children from input object after retrieves the guids
		bankruptcyCaseAction.removeAllChildren(CaseAccount.CLASS_ID);
		bankruptcyCaseAction.setAccountGuid(accountGuids);
		CaseActionService bcaService = (CaseActionService) ServiceFactory.getInstance().lookup(CaseActionService.LOOKUP_NAME);
		LOG.debug("Updating Case and Case Account for CaseID: {} and Action: {} ", caseID, bankruptcyCaseActionDTO.getAction());
		updatedCaseAction = bcaService.processBankruptcyCaseAction(bankruptcyCaseAction);
		List<Problem> problemList = updatedCaseAction.getChildren(Problem.CLASS_ID);
		if (!problemList.isEmpty()) {
			LOG.error("Case action failed with problem(s) for {}", caseID);
			throw new C360ValidationException(ErrorUtil.problemToValidationError(problemList));
		}
		return LOG.exit(new StatusResponseDTO(StatusResponseDTO.SUCCESS));
	}

	/**
	 * Updates case account with action.
	 * @param bankruptcyCaseAccountActionDTO 
	 * @param caseID 
	 * @param locationCode 
	 * @param accountNumber  
	 * @return StatusResponseDTO
	 */
	@Operation(summary = "Update an existing Case Account", description = "Updates the details of the case account for the indicated case and account with the case account provided.")
	@ApiResponses(value = { @ApiResponse(responseCode = "200", description = "Successfully saved the case account."),
			@ApiResponse(responseCode = "400", description = "Bad Request") })
	@PostMapping(value = "/cases/{caseID}/accounts/{locationCode}/{accountNumber}/action")
	public StatusResponseDTO addCaseAccountWithAction(
			@RequestBody BankruptcyCaseAccountActionDTO bankruptcyCaseAccountActionDTO,
			@PathVariable("caseID") String caseID, @PathVariable("locationCode") String locationCode,
			@PathVariable("accountNumber") String accountNumber) {
		LOG.entry(caseID, locationCode, accountNumber );
		Assert.isTrue(caseID.equalsIgnoreCase(bankruptcyCaseAccountActionDTO.getCaseID()), LOG_INVALID_CASE_ID);
		Assert.isTrue(locationCode.equalsIgnoreCase(bankruptcyCaseAccountActionDTO.getLocationCode()),
				LOG_INVALID_LOCATION_CODE);
		Assert.isTrue(accountNumber.equalsIgnoreCase(bankruptcyCaseAccountActionDTO.getAccountNumber()),
				LOG_INVALID_ACCOUNT_NUMBER);
		CaseAccountActionAddressDTO addressIds = bankruptcyCaseAccountActionDTO.getAddressId();
		// Convert DTO to Domain
		BankruptcyCaseAccountAction bankruptcyCaseAccountAction = (BankruptcyCaseAccountAction) BankruptcyCaseAccountActionDTO
				.toDomain(bankruptcyCaseAccountActionDTO, modelMapper);
		CaseAccount caseAccount = (CaseAccount) DomainObjectFactory.getInstance().newObject(CaseAccount.CLASS_ID);
		caseAccount.setCaseID(caseID);
		caseAccount.setAccountNumber(accountNumber);
		caseAccount.setLocationCode(locationCode);
		bankruptcyCaseAccountAction.setCaseAccount(Arrays.asList(caseAccount));
		String guid = "";
		if (addressIds.getCollectionContGuid() != null && addressIds.getExternalKey() != null) {
			LOG.debug("Updating BankruptcyCaseAccountAction with Address {}", addressIds.getExternalKey());
			guid = addressIds.getCollectionContGuid() + "." + addressIds.getExternalKey();
		}
		bankruptcyCaseAccountAction.setAddressId(guid);
		// Adding Contacts to bankruptcyCaseAccountAction
		addContactsToCaseAccountAction(bankruptcyCaseAccountActionDTO, bankruptcyCaseAccountAction);
		CaseActionService bcaService = (CaseActionService) ServiceFactory.getInstance()
				.lookup(CaseActionService.LOOKUP_NAME);
		// Call process bankruptcy case account action
		BooleanObj updatedCaseAction = bcaService.processBankruptcyCaseAccountAction(bankruptcyCaseAccountAction);
		List<Problem> problemList = updatedCaseAction.getChildren(Problem.CLASS_ID);
		if (!problemList.isEmpty()) {
			LOG.error("Case account action failed with problem(s) for {}, {}, {}", caseID, locationCode, accountNumber);
			throw new C360ValidationException(ErrorUtil.problemToValidationError(problemList));
		}
		return LOG.exit(new StatusResponseDTO(StatusResponseDTO.SUCCESS));
	}

	/**
	 * adds case accounts for a bankruptcy case
	 * 
	 * @param caseID
	 * @param model
	 * @return StatusResponseDTO
	 */
	@PostMapping(value = "/cases/{caseID}/accounts")
	public StatusResponseDTO addCaseAccounts(@PathVariable("caseID") String caseId,
			@Valid @RequestBody AssociateCaseAccountDTO associateCaseAccountDTO) {
		LOG.entry(associateCaseAccountDTO);
		Assert.isTrue(caseId.equalsIgnoreCase(associateCaseAccountDTO.getCaseID()), LOG_INVALID_CASE_ID);
		List<StringObj> accountGuids = new ArrayList<>();
		List<AssociateAccountDTO> accountList = associateCaseAccountDTO.getAccounts();
		//validates duplicate accountList
		List<Problem> duplicateProblemList=validateDuplicateCaseAccount(accountList);
		if (!duplicateProblemList.isEmpty()) {
			LOG.error("Associating the accountList failed with problem(s) {}", duplicateProblemList);
			throw new C360ValidationException(ErrorUtil.problemToValidationError(duplicateProblemList));
		}
		if (!accountList.isEmpty()) {
			LOG.debug("Processing the accountList for associating account to case {}", accountList);
			for (AssociateAccountDTO account : accountList) {
				LOG.debug("Processing the account with loactionCode {} and accountNumber {}", account.getLocationCode(), account.getAccountNumber());
				StringObj stringObj = (StringObj) DomainObjectFactory.getInstance().newObject(StringObj.CLASS_ID);
				stringObj.setData(account.getLocationCode() + BCMConstants.DOT + account.getAccountNumber());
				accountGuids.add(stringObj);
			}
			CaseAccountDetails caseAccountDetails = (CaseAccountDetails) DomainObjectFactory.getInstance()
					.newObject(CaseAccountDetails.CLASS_ID);
			caseAccountDetails.setAccountGuid(accountGuids);
			caseAccountDetails.setCaseID(caseId);
			BcmMgmtService bcmService = (BcmMgmtService) ServiceFactory.getInstance()
					.lookup(BcmMgmtService.LOOKUP_NAME);
			CaseAccount caseAccount = bcmService.addCaseAccounts(caseAccountDetails);
			List<Problem> problemList = caseAccount.getChildren(Problem.CLASS_ID);
			if (!problemList.isEmpty()) {
				LOG.error("Retrieving case failed with problem(s) for {}", caseId);
				throw new C360ValidationException(ErrorUtil.problemToValidationError(problemList));
			}
		}
		return LOG.exit(new StatusResponseDTO(StatusResponseDTO.SUCCESS));
	}
	
	/**
	 * Validates Duplicate accountList.
	 * @param accountList                  
	 * @return problemList
	 */
	private List<Problem> validateDuplicateCaseAccount(List<AssociateAccountDTO> accountList){
		LOG.entry(accountList);
        // List of accounts used to find the duplicate
        List<AssociateAccountDTO> uniqueAccountList = new ArrayList<>();
        List<Problem> problemList = new ArrayList<>();
        boolean isAccountDuplicate=Boolean.FALSE;
        for (AssociateAccountDTO account : accountList) {
            if (uniqueAccountList.contains(account)) {
                LOG.debug("Exit when duplicate case account is found in list", isAccountDuplicate);
                isAccountDuplicate=Boolean.TRUE;
                break;
            } else {
                LOG.debug("Adding unique case account", account);
                uniqueAccountList.add(account);
            }
        }
        
        if (Boolean.TRUE.equals(isAccountDuplicate)) {
            LOG.error("Problem processing duplicate accounts: {}", isAccountDuplicate);
            Problem problem = (Problem) ProblemUtil.getInstance().getProblemFactory().getNewProblem(
                    ProblemNumbers.DUPLICATE_ACCOUNTS, null, null, (Parameter[]) null,
                    Problem.SEVERITY_ERROR);
            problemList.add(problem);
			return LOG.exit(problemList);
        }
        return LOG.exit(problemList);
	}
	/**
	 * Edits BankruptcyCase.
	 *
	 * @param casePatch     
	 * @param caseId  
	 *                    
	 * @return UpdateBankruptcyCaseDTO
	 */
	@Operation(summary="Update an existing Case",
			description="Updates the details of the case for the case provided."
		)
		@ApiResponses(value = {
			@ApiResponse(responseCode = "200", description = "Successfully updated the case."),
			@ApiResponse(responseCode = "400", description = "Bad Request")
		})
	@PatchMapping(path = "/cases/{caseId}", consumes = "application/json-patch+json")
	public UpdateBankruptcyCaseDTO updateCaseDetails(@RequestBody JsonPatch casePatch, @PathVariable("caseId") String caseId) {
		LOG.entry(casePatch);
		
		BankruptcyCase bankruptcyCase = (BankruptcyCase) DomainObjectFactory.getInstance().newObject(BankruptcyCase.CLASS_ID);
		bankruptcyCase.setCaseID(caseId);
		bankruptcyCase = (BankruptcyCase) ServiceUtils.loadObjectByBK(bankruptcyCase, false);
		if (bankruptcyCase == null) {
			LOG.error("Bankruptcy Case not found while update for: {}", caseId);
			Problem problem = (Problem) DomainObjectFactory.getInstance().newObject(Problem.CLASS_ID);
			problem.setErrorSymbol(ProblemNumbers.MSG_NO_RECORDS);
			problem.setDescription("No Bankruptcy Case Records returned for entered starting key value");
			List<Problem> problemList = new ArrayList<>();
			problemList.add(problem);
			throw new C360ValidationException(ErrorUtil.problemToValidationError(problemList));
		}
		String domainCaseStatus=bankruptcyCase.getActiveStatus();
		UpdateBankruptcyCaseDTO bankruptcyCaseDto = UpdateBankruptcyCaseDTO.of(bankruptcyCase, modelMapper);
		try {
			/*	Applying patch on DTO object which will replace existing domain field value with the patch 
			 *  value and once patch value is applied convert DTO to domain and call update method().* */
			JsonNode bankruptcyCasePatched = casePatch.apply(objectMapper.convertValue(bankruptcyCaseDto, JsonNode.class));
			bankruptcyCaseDto = objectMapper.treeToValue(bankruptcyCasePatched, UpdateBankruptcyCaseDTO.class);
		} catch (JsonPatchException | JsonProcessingException e) {
			LOG.error("Problem while applying patch {} ", bankruptcyCase);
			throw new C360RuntimeException(e);
		}
		Set<ConstraintViolation<UpdateBankruptcyCaseDTO>>  violations = validator.validate(bankruptcyCaseDto);
		if(!violations.isEmpty()) {
			LOG.error("Error occured in validating bankruptcyCaseDto while update for: {}", caseId);
			List<Problem> problemList = new ArrayList<>();
			for(ConstraintViolation<UpdateBankruptcyCaseDTO> constraintViolation : violations) {
				LOG.error("Creating problem for casePatch validation fail for: {}", caseId);
				String errorMsg = constraintViolation.getPropertyPath() + SPACE + constraintViolation.getMessage();
				Problem problem = (Problem) DomainObjectFactory.getInstance().newObject(Problem.CLASS_ID);
				problem.setErrorSymbol(ProblemNumbers.FIELD_IS_REQUIRED);
				problem.setDescription(errorMsg);
				problemList.add(problem);
			}
			throw new C360ValidationException(ErrorUtil.problemToValidationError(problemList));
		}
		Assert.isTrue(caseId.equalsIgnoreCase(bankruptcyCaseDto.getCaseID()), LOG_INVALID_CASE_ID);
		BankruptcyCase bankruptcyCasePatched = UpdateBankruptcyCaseDTO.toDomain(bankruptcyCaseDto, bankruptcyCase, modelMapper);
		bankruptcyCasePatched.setGuid(bankruptcyCase.getGuid());
		
		// Validates the CaseActiveStatus 
		bankruptcyCasePatched=validateCaseStatus(domainCaseStatus, bankruptcyCasePatched, casePatch);
		
		List<Problem> problemStatusList =bankruptcyCasePatched.getChildren(Problem.CLASS_ID);
		if (!problemStatusList.isEmpty()) {
			LOG.error("Updating Case failed with problem(s) {} ", ProblemUtil.getInstance().extractProblems(bankruptcyCasePatched));
			throw new C360ValidationException(ErrorUtil.problemToValidationError(problemStatusList));
		}
		BcmMgmtService bcmService = (BcmMgmtService) ServiceFactory.getInstance().lookup(BcmMgmtService.LOOKUP_NAME);
		bankruptcyCasePatched = bcmService.updateCase(bankruptcyCasePatched);
		List<Problem> problemList = bankruptcyCasePatched.getChildren(Problem.CLASS_ID);
		if (!problemList.isEmpty()) {
			LOG.error("Updating case failed with problem(s) for {}", caseId);
			throw new C360ValidationException(ErrorUtil.problemToValidationError(problemList));
		}
			return LOG.exit(UpdateBankruptcyCaseDTO.of(bankruptcyCasePatched, modelMapper));
	}
	
	/**
	 * Validates Case Status.
	 *
	 * @param domainCaseStatus
	 * @param bankruptcyCasePatched     
	 * @param casePatch  
	 *                    
	 * @return bankruptcyCasePatched
	 */
	private BankruptcyCase validateCaseStatus(String domainCaseStatus, BankruptcyCase bankruptcyCasePatched, JsonPatch casePatch){
		LOG.entry(domainCaseStatus, bankruptcyCasePatched, casePatch);
		
		String requestCaseStatus=bankruptcyCasePatched.getActiveStatus();
		
		//Splitting to Check the length of JsonPatch RequestBody
	    String[] patchValues = casePatch.toString().split(",");
	    
		if(BCMConstants.BCM_INACTIVE_STATUS.equalsIgnoreCase(domainCaseStatus) && BCMConstants.BCM_INACTIVE_STATUS.equalsIgnoreCase(requestCaseStatus) || 
				BCMConstants.BCM_PRGPEND_STATUS.equalsIgnoreCase(domainCaseStatus) && BCMConstants.BCM_PRGPEND_STATUS.equalsIgnoreCase(requestCaseStatus)) {
			LOG.error("Error occured while validating the Domain CaseStatus and Patch CaseStatus : {}, {} ", 
					domainCaseStatus, requestCaseStatus);
			Problem problem = (Problem) ProblemUtil.getInstance().getProblemFactory().getNewProblem(
					ProblemNumbers.BCM_CASE_INACTIVE_STATUS, BankruptcyCase.CLASS_ID, null, (Parameter[]) null, Problem.SEVERITY_ERROR);
			bankruptcyCasePatched.addChild(problem);
			return LOG.exit(bankruptcyCasePatched);
		}
		
		//When Domain CaseStatus and Patch CaseStatus is INACTIVE or PRGPEND we are not allowed to update fields other than ActiveStatus
		if(patchValues.length > 1 && BCMConstants.BCM_INACTIVE_STATUS.equalsIgnoreCase(domainCaseStatus) && 
				BCMConstants.BCM_PRGPEND_STATUS.equalsIgnoreCase(requestCaseStatus) || patchValues.length > 1 && 
				BCMConstants.BCM_PRGPEND_STATUS.equalsIgnoreCase(domainCaseStatus) && BCMConstants.BCM_INACTIVE_STATUS.equalsIgnoreCase(requestCaseStatus)) {
			LOG.error("Error occured when Domain CaseStatus and Patch CaseStatus is PRGPEND or INACTIVE: {}, {} ", 
					domainCaseStatus, requestCaseStatus);
			Problem problem = (Problem) ProblemUtil.getInstance().getProblemFactory().getNewProblem(
					ProblemNumbers.BCM_CASE_INACTIVE_STATUS, BankruptcyCase.CLASS_ID, null, (Parameter[]) null, Problem.SEVERITY_ERROR);
			bankruptcyCasePatched.addChild(problem);
			return LOG.exit(bankruptcyCasePatched);
		}
		return LOG.exit(bankruptcyCasePatched);
	}


	/**
	 * updates the Case Account.
	 *
	 * @param caseAccountPatch
	 * @param caseId           
	 * @param locCode         
	 * @param acctNum          
	 * @return CaseAccountDTO
	 */
	@Operation(summary="Update an existing Case Account",
			description="Updates the details of the case account for the indicated case and account with the case account provided."
	)
	@ApiResponses(value = {
			@ApiResponse(responseCode = "200", description = "Successfully updated the case account."),
			@ApiResponse(responseCode = "400", description = "Bad Request")
	})
	@PatchMapping(value = "/cases/{caseId}/accounts/{locationCode}/{accountNumber}", consumes = "application/json-patch+json")
	public CaseAccountDTO updateCaseAccount(@RequestBody JsonPatch caseAccountPatch, @PathVariable("caseId") String caseId, 
			@PathVariable("locationCode") String locCode, @PathVariable("accountNumber") String acctNum) {
		LOG.entry(caseAccountPatch);
		LOG.debug("Update CaseAccount: {}, {}, {}", caseId, locCode, acctNum);
		CaseAccount caseAccount = (CaseAccount) DomainObjectFactory.getInstance().newObject(CaseAccount.CLASS_ID);
		caseAccount.setCaseID(caseId);
		caseAccount.setLocationCode(locCode);
		caseAccount.setAccountNumber(acctNum);
		caseAccount = (CaseAccount) ServiceUtils.loadObjectByBK(caseAccount, false);
		if (caseAccount == null) {
			LOG.error("Case Account not found while update for: {}, {}, {}", caseId, locCode, acctNum);
			Problem problem = (Problem) DomainObjectFactory.getInstance().newObject(Problem.CLASS_ID);
			problem.setErrorSymbol(ProblemNumbers.MSG_NO_RECORDS);
			problem.setDescription("No Case Account Records returned for entered starting key value");
			List<Problem> problemList = new ArrayList<>();
			problemList.add(problem);
			throw new C360ValidationException(ErrorUtil.problemToValidationError(problemList));
		}
		CaseAccountDTO caseAccountDto = CaseAccountDTO.of(caseAccount, modelMapper);
		try {
			/*	Applying patch on DTO object which will replace existing domain field value with the patch 
			 *  value and once patch value is applied convert DTO to domain and call update method().* */
			JsonNode patched = caseAccountPatch.apply(objectMapper.convertValue(caseAccountDto, JsonNode.class));
			caseAccountDto = objectMapper.treeToValue(patched, CaseAccountDTO.class);
		} catch (JsonPatchException | JsonProcessingException e) {
			throw new C360RuntimeException(e);
		}
		Set<ConstraintViolation<CaseAccountDTO>>  violations = validator.validate(caseAccountDto);
		if(!violations.isEmpty()) {
			LOG.error("Error occured in validating caseAccountDto while update for: {}, {}, {}", caseId, locCode, acctNum);
			List<Problem> problemList = new ArrayList<>();
			for(ConstraintViolation<CaseAccountDTO> constraintViolation : violations) {
				LOG.error("Creating problem for caseAccountDto validation fail for: {}, {}, {}", caseId, locCode, acctNum);
				String errorMsg = constraintViolation.getPropertyPath() + SPACE + constraintViolation.getMessage();
				Problem problem = (Problem) DomainObjectFactory.getInstance().newObject(Problem.CLASS_ID);
				problem.setErrorSymbol(ProblemNumbers.FIELD_IS_REQUIRED);
				problem.setDescription(errorMsg);
				problemList.add(problem);
			}
			throw new C360ValidationException(ErrorUtil.problemToValidationError(problemList));
		}
		Assert.isTrue(caseId.equalsIgnoreCase(caseAccountDto.getCaseID()), LOG_INVALID_CASE_ID);
		Assert.isTrue(locCode.equalsIgnoreCase(caseAccountDto.getLocationCode()), LOG_INVALID_LOCATION_CODE);
		Assert.isTrue(acctNum.equalsIgnoreCase(caseAccountDto.getAccountNumber()), LOG_INVALID_ACCOUNT_NUMBER);
		CaseAccount caseAccountPatched = CaseAccountDTO.toDomain(caseAccountDto, caseAccount, modelMapper);
		BcmMgmtService bcmService = (BcmMgmtService) ServiceFactory.getInstance().lookup(BcmMgmtService.LOOKUP_NAME);
		// Updating case account
		caseAccountPatched = bcmService.updateCaseAccount(caseAccountPatched);
		List<Problem> problemList = caseAccountPatched.getChildren(Problem.CLASS_ID);
		if (!problemList.isEmpty()) {
			LOG.error("Updating Case Account  failed with problem(s) for {}, {}, {}, {}", caseId, locCode, acctNum);
			throw new C360ValidationException(ErrorUtil.problemToValidationError(problemList));
		}
		 LOG.debug("Case Account update is successfull...");
		return LOG.exit(CaseAccountDTO.of(caseAccountPatched, modelMapper));
	}

	/**
	 * updates the Bankruptcy Case Account Action
	 * @param bankruptcyCaseAccountActionDTO
	 * @param bankruptcyCaseAccountAction
	 * @return bankruptcyCaseAccountAction
	 */
	private BankruptcyCaseAccountAction addContactsToCaseAccountAction(BankruptcyCaseAccountActionDTO bankruptcyCaseAccountActionDTO,
			BankruptcyCaseAccountAction bankruptcyCaseAccountAction) {
		LOG.entry(bankruptcyCaseAccountActionDTO.getCaseID());
		List<String> contactIdsList = bankruptcyCaseAccountActionDTO.getContactIds();
		if (!contactIdsList.isEmpty()) {
			LOG.debug("Checking the input contact Ids for setting to BankruptcyCaseAccountAction");
			List<String> tempContactList = contactIdsList.stream().map(object -> Objects.toString(object, null))
					.collect(Collectors.toList());
			tempContactList = tempContactList.stream().distinct().collect(Collectors.toList());
			CaseAccountContact caseAccountContact = null;
			List<CaseAccountContact> contacts = new ArrayList<>();
			for (String contactId : tempContactList) {
				LOG.debug("Setting Case Account Contact to BankruptcyCaseAccountAction {}",contactId);
				caseAccountContact = (CaseAccountContact) DomainObjectFactory.getInstance()
						.newObject(CaseAccountContact.CLASS_ID);
				
				caseAccountContact.setCaseID(bankruptcyCaseAccountActionDTO.getCaseID());
				caseAccountContact.setAccountNumber(bankruptcyCaseAccountActionDTO.getAccountNumber());
				caseAccountContact.setLocationCode(bankruptcyCaseAccountActionDTO.getLocationCode());
				caseAccountContact.setContactId(contactId);
				contacts.add(caseAccountContact);
			}
			bankruptcyCaseAccountAction.setCaseAccountContacts(contacts);
		}
		return LOG.exit(bankruptcyCaseAccountAction);
	}

	/**
	 * adds a new Bankruptcy Plan for an account.
	 *
	 * @param bankruptcyPlanModel 
	 * @param caseID             
	 * @param locationCode      
	 * @param accountNumber      
	 * @return BankruptcyPlanDTO
	 */
	@Operation(summary="Add bankruptcy plan.",
			description="Add bankruptcy plan for a case account.")
	@ApiResponses(value = {
			@ApiResponse(responseCode = "200", description = "Bankruptcy plan is added successfully."),
			@ApiResponse(responseCode = "400", description = "Bad Request")
	})
	@PostMapping(value = "/cases/{caseID}/accounts/{locationCode}/{accountNumber}/plans", consumes = MediaType.APPLICATION_JSON_VALUE, 
			produces = MediaType.APPLICATION_JSON_VALUE)
	public BankruptcyPlanDTO addAccountBankruptcyPlan(@Valid @RequestBody BankruptcyPlanDTO bankruptcyPlanDTO,
			@PathVariable("caseID") String caseID, @PathVariable("locationCode") String locationCode,
			@PathVariable("accountNumber") String accountNumber) {
		
		LOG.entry(bankruptcyPlanDTO);
		Assert.isTrue(caseID.equalsIgnoreCase(bankruptcyPlanDTO.getCaseID()), LOG_INVALID_CASE_ID);
		Assert.isTrue(locationCode.equalsIgnoreCase(bankruptcyPlanDTO.getLocationCode()), LOG_INVALID_LOCATION_CODE);
		Assert.isTrue(accountNumber.equalsIgnoreCase(bankruptcyPlanDTO.getAccountNumber()), LOG_INVALID_ACCOUNT_NUMBER);
		BankruptcyPlan bankruptcyPlan = BankruptcyPlanDTO.toDomain(bankruptcyPlanDTO, modelMapper);
		BcmMgmtService bcmService = (BcmMgmtService) ServiceFactory.getInstance().lookup(BcmMgmtService.LOOKUP_NAME);
		bankruptcyPlan = bcmService.addBankruptcyPlan(bankruptcyPlan);
		List<Problem> problemList = bankruptcyPlan.getChildren(Problem.CLASS_ID);
		if (!problemList.isEmpty()) {
			LOG.error("Adding plan failed with problem(s) for {}, {}, {}, {}", caseID, locationCode, accountNumber, 
					bankruptcyPlanDTO.getReceivedDate());
			throw new C360ValidationException(ErrorUtil.problemToValidationError(problemList));
		}
		return LOG.exit(BankruptcyPlanDTO.of(bankruptcyPlan, modelMapper));
	}
	
	/**
	 * updates a bankruptcy plan for an case account.
	 * @param bankruptcyPlanPatch
	 * @param caseID
	 * @param locationCode
	 * @param accountNumber
	 * @param receivedDate
	 * @return BankruptcyPlanDTO
	 */
	@Operation(summary="Update an existing bankruptcy plan.",
			description="Updates the details of the bankruptcy plan for the indicated case account."
		)
	@ApiResponses(value = {
		@ApiResponse(responseCode = "200", description = "Successfully updated the bankruptcy plan."),
		@ApiResponse(responseCode = "400", description = "Bad Request")
	})
	@PatchMapping(value = "/cases/{caseID}/accounts/{locationCode}/{accountNumber}/plans/{receivedDate}")
	public BankruptcyPlanDTO updateAccountBankruptcyPlan(@RequestBody JsonPatch bankruptcyPlanPatch,
			@PathVariable("caseID") String caseID, @PathVariable("locationCode") String locationCode,
			@PathVariable("accountNumber") String accountNumber, @PathVariable("receivedDate") String receivedDate) {
		LOG.entry(bankruptcyPlanPatch);
		BankruptcyPlan bankruptcyPlan = (BankruptcyPlan) DomainObjectFactory.getInstance().newObject(BankruptcyPlan.CLASS_ID);
		bankruptcyPlan.setCaseID(caseID);
		bankruptcyPlan.setLocationCode(locationCode);
		bankruptcyPlan.setAccountNumber(accountNumber);
		Timestamp planReceivedDate = Timestamp.valueOf(LocalDate.parse(receivedDate).atStartOfDay());
		bankruptcyPlan.setReceivedDate(planReceivedDate);
		bankruptcyPlan = (BankruptcyPlan) ServiceUtils.loadObjectByBK(bankruptcyPlan, false);
		if (bankruptcyPlan == null) {
			LOG.error("Bankruptcy plan not found while update for: {}, {}, {}, {}", caseID, locationCode, accountNumber, planReceivedDate);
			Problem problem = (Problem) DomainObjectFactory.getInstance().newObject(Problem.CLASS_ID);
			problem.setErrorSymbol(ProblemNumbers.MSG_NO_RECORDS);
			problem.setDescription("No Bankruptcy Plan Records returned for entered starting key value");
			List<Problem> problemList = new ArrayList<>();
			problemList.add(problem);
			throw new C360ValidationException(ErrorUtil.problemToValidationError(problemList));
		}
		BankruptcyPlanDTO bankruptcyPlanDTO = BankruptcyPlanDTO.of(bankruptcyPlan, modelMapper);
		try {
			JsonNode patched = bankruptcyPlanPatch.apply(objectMapper.convertValue(bankruptcyPlanDTO, JsonNode.class));
			bankruptcyPlanDTO = objectMapper.treeToValue(patched, BankruptcyPlanDTO.class);
		} catch (JsonProcessingException | JsonPatchException ex) {
			LOG.error("Error occured in parsing bankruptcyPlanPatch for: {}, {}, {}, {}", caseID, locationCode, accountNumber, planReceivedDate);
			throw new C360RuntimeException(ex);
		}
		Assert.isTrue(caseID.equalsIgnoreCase(bankruptcyPlanDTO.getCaseID()), LOG_INVALID_CASE_ID);
		Assert.isTrue(locationCode.equalsIgnoreCase(bankruptcyPlanDTO.getLocationCode()), LOG_INVALID_LOCATION_CODE);
		Assert.isTrue(accountNumber.equalsIgnoreCase(bankruptcyPlanDTO.getAccountNumber()), LOG_INVALID_ACCOUNT_NUMBER);
		Assert.isTrue(bankruptcyPlanDTO.getReceivedDate() != null && planReceivedDate != null && 
				planReceivedDate.compareTo(bankruptcyPlanDTO.getReceivedDate()) == 0 , LOG_INVALID_PLAN_RECEIVED_DATE);
		Set<ConstraintViolation<BankruptcyPlanDTO>>  violations = validator.validate(bankruptcyPlanDTO);
		if(!violations.isEmpty()) {
			LOG.error("Error occured in validating bankruptcyPlanPatch while update for: {}, {}, {}, {}", caseID, locationCode, accountNumber, 
					planReceivedDate);
			List<Problem> problemList = new ArrayList<>();
			for(ConstraintViolation<BankruptcyPlanDTO> constraintViolation : violations) {
				LOG.error("Creating problem for bankruptcyPlanPatch validation fail for: {}, {}, {}, {}", caseID, locationCode, accountNumber, 
						planReceivedDate);
				String errorMsg = constraintViolation.getPropertyPath() + SPACE + constraintViolation.getMessage();
				Problem problem = (Problem) DomainObjectFactory.getInstance().newObject(Problem.CLASS_ID);
				problem.setErrorSymbol(ProblemNumbers.FIELD_IS_REQUIRED);
				problem.setDescription(errorMsg);
				problemList.add(problem);
			}
			throw new C360ValidationException(ErrorUtil.problemToValidationError(problemList));
		}
		bankruptcyPlan = BankruptcyPlanDTO.toDomain(bankruptcyPlanDTO, modelMapper);
		BcmMgmtService bcmService = (BcmMgmtService) ServiceFactory.getInstance().lookup(BcmMgmtService.LOOKUP_NAME);
		bankruptcyPlan = bcmService.updateBankruptcyPlan(bankruptcyPlan);
		List<Problem> problemList = bankruptcyPlan.getChildren(Problem.CLASS_ID);
		if (!problemList.isEmpty()) {
			LOG.error("Updating Bankruptcy Plan failed with problem(s) for {}, {}, {}, {}", caseID, locationCode, accountNumber, planReceivedDate);
			throw new C360ValidationException(ErrorUtil.problemToValidationError(problemList));
		}
		return LOG.exit(BankruptcyPlanDTO.of(bankruptcyPlan, modelMapper));
	}

	/**
	 * Adding/Updating Bankruptcy case details with children for
	 * onBoardingCaseDetails
	 * 
	 * @param bankruptcyCaseDTO
	 * @return BankruptcyCaseDTO
	 */
	@PostMapping(value = "/cases/case/onboarding", consumes = MediaType.APPLICATION_JSON_VALUE, produces = MediaType.APPLICATION_JSON_VALUE)
	public BankruptcyCaseDTO onBoardingCaseDetails(@Valid @RequestBody BankruptcyCaseDTO bankruptcyCaseDTO) {
		LOG.entry(bankruptcyCaseDTO);
		Assert.notNull(bankruptcyCaseDTO, "Bankruptcy Case DTO is null");
		BankruptcyCase bankruptcyCase = BankruptcyCaseDTO.toDomain(bankruptcyCaseDTO, modelMapper);
		BcmMgmtService bcmService = (BcmMgmtService) ServiceFactory.getInstance().lookup(BcmMgmtService.LOOKUP_NAME);
		BankruptcyCase bankruptcyCaseObj = bcmService.onBoardCase(bankruptcyCase);
		List<Problem> problemList = bankruptcyCaseObj.getChildren(Problem.CLASS_ID);
		if (!problemList.isEmpty()) {
			LOG.error("Processing error for adding/updating on boarding case deatils:{}", bankruptcyCaseObj.getCaseID());
			throw new C360ValidationException(ErrorUtil.problemToValidationError(problemList));
		}
		return LOG.exit(BankruptcyCaseDTO.of(bankruptcyCaseObj, modelMapper));
	}
	
	
	/**
	 * Edit case debtor
	 * @param JsonPatch
	 * @param caseId           
	 * @param debtorId  
	 * @return CaseDebtorDTO
	 */
	@Operation(summary="Update an existing Case Debtor",
			description="Updates the details of the case debtor for the indicated case."
		)
	@ApiResponses(value = {
		@ApiResponse(responseCode = "200", description = "Successfully updated the case debtor."),
		@ApiResponse(responseCode = "400", description = "Bad Request")
	})
	@PatchMapping(path = "/cases/{caseId}/debtors/{debtorId}", consumes = "application/json-patch+json")
	public CaseDebtorDTO updateCaseDebtor(@RequestBody JsonPatch caseDebtorPatch, @PathVariable("caseId") String caseId,
			@PathVariable("debtorId") String debtorId) {
		LOG.entry(caseId, debtorId);

		CaseDebtor caseDebtor = (CaseDebtor) DomainObjectFactory.getInstance().newObject(CaseDebtor.CLASS_ID);
		caseDebtor.setCaseID(caseId);
		caseDebtor.setDebtorId(debtorId);
		caseDebtor = (CaseDebtor) ServiceUtils.loadObjectByBK(caseDebtor, false);
		if (caseDebtor == null) {
			LOG.error("Case Debtor not found while update for: {}, {}", caseId, debtorId);
			Problem problem = (Problem) DomainObjectFactory.getInstance().newObject(Problem.CLASS_ID);
			problem.setErrorSymbol(ProblemNumbers.MSG_NO_RECORDS);
			problem.setDescription("No Case Debtor Records returned for entered starting key value");
			List<Problem> problemList = new ArrayList<>();
			problemList.add(problem);
			throw new C360ValidationException(ErrorUtil.problemToValidationError(problemList));
		}
		CaseDebtorDTO debtorDto = CaseDebtorDTO.of(caseDebtor, modelMapper);	
		try {
			/*	Applying patch on DTO object which will replace existing domain field value with the patch 
			 *  value and once patch value is applied convert DTO to domain and call update method().* */
			JsonNode patched = caseDebtorPatch.apply(objectMapper.convertValue(debtorDto, JsonNode.class));
			debtorDto = objectMapper.treeToValue(patched, CaseDebtorDTO.class);
		} catch (JsonPatchException | JsonProcessingException e) {
			throw new C360RuntimeException(e);
		}
		Set<ConstraintViolation<CaseDebtorDTO>>  violations = validator.validate(debtorDto);
		if(!violations.isEmpty()) {
			LOG.error("Error occured in validating caseDebtorPatch while update for: {}, {}", caseId, debtorId);
			List<Problem> problemList = new ArrayList<>();
			for(ConstraintViolation<CaseDebtorDTO> constraintViolation : violations) {
				LOG.error("Creating problem for caseDebtorPatch validation fail for: {}, {}", caseId, debtorId);
				String errorMsg = constraintViolation.getPropertyPath() + SPACE + constraintViolation.getMessage();
				Problem problem = (Problem) DomainObjectFactory.getInstance().newObject(Problem.CLASS_ID);
				problem.setErrorSymbol(ProblemNumbers.FIELD_IS_REQUIRED);
				problem.setDescription(errorMsg);
				problemList.add(problem);
			}
			throw new C360ValidationException(ErrorUtil.problemToValidationError(problemList));
		}
		Assert.isTrue(caseId.equalsIgnoreCase(debtorDto.getCaseID()), LOG_INVALID_CASE_ID);
		CaseDebtor caseDebtorPatched = CaseDebtorDTO.toDomain(debtorDto, modelMapper);
		caseDebtorPatched.setGuid(caseDebtor.getGuid());
		BcmMgmtService bcmService = (BcmMgmtService) ServiceFactory.getInstance().lookup(BcmMgmtService.LOOKUP_NAME);
		caseDebtorPatched = bcmService.updateCaseDebtor(caseDebtorPatched);
		List<Problem> problemList = caseDebtorPatched.getChildren(Problem.CLASS_ID);
		if (!problemList.isEmpty()) {
			LOG.error("Updating Case Debtor failed with problem(s) for {}, {}", caseId, debtorId);
			throw new C360ValidationException(ErrorUtil.problemToValidationError(problemList));
		}
		return LOG.exit(CaseDebtorDTO.of(caseDebtorPatched, modelMapper));
	}
	
	/**
	 * Add Contacts to the caseAccountContact.
	 *
	 * @param caseAccountContactDTO
	 * @param caseID
	 * @param locationCode
	 * @param accountNumber
	 * @return CaseAccountContactDTO
	 */
	@Operation(summary="Add a new case account contact",
			description="Adds the details of the case account contact for the indicated case and account with the case account contact provided.")
	@ApiResponses(value = {
		@ApiResponse(responseCode = "200", description = "Case account contact added successfully."),
		@ApiResponse(responseCode = "400", description = "Bad Request")
	})
	@PostMapping(value = "/cases/{caseID}/accounts/{locationCode}/{accountNumber}/contact", consumes = MediaType.APPLICATION_JSON_VALUE, produces = MediaType.APPLICATION_JSON_VALUE)
	public CaseAccountContactDTO addCaseAccountContact(@Valid @RequestBody CaseAccountContactDTO caseAccountContactDTO,
			@PathVariable("caseID") String caseID, @PathVariable("locationCode") String locationCode,
			@PathVariable("accountNumber") String accountNumber) {
		LOG.entry(caseAccountContactDTO);
		Assert.notNull(caseAccountContactDTO, "CaseAccountContactModel is null");
		Assert.isTrue(caseID.equalsIgnoreCase(caseAccountContactDTO.getCaseID()), LOG_INVALID_CASE_ID);
		Assert.isTrue(locationCode.equalsIgnoreCase(caseAccountContactDTO.getLocationCode()), LOG_INVALID_LOCATION_CODE);
		Assert.isTrue(accountNumber.equalsIgnoreCase(caseAccountContactDTO.getAccountNumber()), LOG_INVALID_ACCOUNT_NUMBER);
		CaseAccountContact caseAccountContact = caseAccountContactDTO.toDomain(caseAccountContactDTO, modelMapper);
		BcmMgmtService bcmService = (BcmMgmtService) ServiceFactory.getInstance().lookup(BcmMgmtService.LOOKUP_NAME);
		caseAccountContact = bcmService.addCaseAccountContact(caseAccountContact);
		List<Problem> problemList = caseAccountContact.getChildren(Problem.CLASS_ID);
		if (!problemList.isEmpty()) {
			LOG.error("Adding Case Account Contact failed with problem(s) for {}, {}, {}", caseID, locationCode, accountNumber);
			throw new C360ValidationException(ErrorUtil.problemToValidationError(problemList));
		}
		return LOG.exit(caseAccountContactDTO.of(caseAccountContact, modelMapper));
	}
	
	/**
	 * Associates the contact to the debtor.
	 *
	 * @param caseID
	 * @param debtorId
	 * @param contactGuidList
	 * @return StatusResponseDTO
	 */
	@Operation(summary="Add a new contact debtor",
			description="Adds the details of the contact debtor for the indicated case and debtor  with the contactId's provided.")
	@ApiResponses(value = {
		@ApiResponse(responseCode = "200", description = "Contact debtors added successfully."),
		@ApiResponse(responseCode = "400", description = "Bad Request")
	})
	@PostMapping(value = "/cases/{caseID}/debtor/{debtorId}/contactdebtors", consumes = MediaType.APPLICATION_JSON_VALUE, produces = MediaType.APPLICATION_JSON_VALUE)
	public StatusResponseDTO addContactDebtors(@PathVariable("caseID") String caseID, @PathVariable("debtorId") String debtorId,
			@RequestBody String[] contactIdList) {
		LOG.entry(caseID, debtorId, contactIdList);
        Assert.notNull(caseID, "Case ID must be having value");
        Assert.notNull(debtorId, "Debtor id must be having value");
		Assert.notNull(contactIdList, "contactIdList is null");
		
		List<StringObj> contactGuids = new ArrayList<>();
		if (contactIdList.length != 0) {
			LOG.debug("Processing the contactIdList for associating contact to case debtor {}", contactIdList);
			StringObj stringObj = null;
			List<String> list = new ArrayList<>(Arrays.asList(contactIdList));
			List<String> newList = list.stream().distinct().collect(Collectors.toList());
			for (String contactId : newList) {
				LOG.debug("Processing the contactId {}", contactId);
				stringObj = (StringObj) DomainObjectFactory.getInstance().newObject(StringObj.CLASS_ID);
				stringObj.setData(contactId);
				contactGuids.add(stringObj);
			}
			CaseDebtor caseDebtor = (CaseDebtor) DomainObjectFactory.getInstance().newObject(CaseDebtor.CLASS_ID);
			caseDebtor.setCaseID(caseID);
			caseDebtor.setDebtorId(debtorId);
			String debtorGuid =  ServiceUtils.lookupPKByBK(caseDebtor);
			AddContactDebtor addContactDebtor = (AddContactDebtor) DomainObjectFactory.getInstance()
					.newObject(AddContactDebtor.CLASS_ID);
			addContactDebtor.setDebtorGuid(debtorGuid);
			addContactDebtor.setContactGuids(contactGuids);
			addContactDebtor.setCaseID(caseID);

			BcmMgmtService bcmService = (BcmMgmtService) ServiceFactory.getInstance()
					.lookup(BcmMgmtService.LOOKUP_NAME);
			ContactDebtor contactDebtor = bcmService.addContactDebtor(addContactDebtor);
			List<Problem> problemList = contactDebtor.getChildren(Problem.CLASS_ID);
			if (!problemList.isEmpty()) {
				LOG.error("Adding contact debtor failed with problem(s) for {}, {}", caseID, debtorId);
				throw new C360ValidationException(ErrorUtil.problemToValidationError(problemList));
			}
		}
		return LOG.exit(new StatusResponseDTO(StatusResponseDTO.SUCCESS));
	}
	
	/**
	 * adds a new Proof Of Claim for an account.
	 * @param proofOfClaimDTO
	 * @param caseID
	 * @param locationCode
	 * @param accountNumber
	 * @return ProofOfClaimModel
	 */
	@Operation(summary="Add Proof of Claim.",
			description="Add Proof of Claim for a case account."
			)
	@ApiResponses(value = {
			@ApiResponse(responseCode = "200", description = "Proof of claim is added successfully."),
			@ApiResponse(responseCode = "400", description = "Bad Request")
	})
	@PostMapping(value = "/cases/{caseID}/accounts/{locationCode}/{accountNumber}/pocs", consumes = MediaType.APPLICATION_JSON_VALUE, 
	produces = MediaType.APPLICATION_JSON_VALUE)
	public ProofOfClaimDTO addAccountProofOfClaim(@Valid @RequestBody ProofOfClaimDTO proofOfClaimDTO,
			@PathVariable("caseID") String caseID, @PathVariable("locationCode") String locationCode,
			@PathVariable("accountNumber") String accountNumber) {
		LOG.entry(proofOfClaimDTO);
		Assert.isTrue(caseID.equalsIgnoreCase(proofOfClaimDTO.getCaseID()), LOG_INVALID_CASE_ID);
		Assert.isTrue(locationCode.equalsIgnoreCase(proofOfClaimDTO.getLocationCode()), LOG_INVALID_LOCATION_CODE);
		Assert.isTrue(accountNumber.equalsIgnoreCase(proofOfClaimDTO.getAccountNumber()), LOG_INVALID_ACCOUNT_NUMBER);
		ProofOfClaim proofOfClaim = ProofOfClaimDTO.toDomain(proofOfClaimDTO, modelMapper);
		BcmMgmtService bcmService = (BcmMgmtService) ServiceFactory.getInstance().lookup(BcmMgmtService.LOOKUP_NAME);
		proofOfClaim = bcmService.addProofOfClaim(proofOfClaim);
		List<Problem> problemList = proofOfClaim.getChildren(Problem.CLASS_ID);
		if (!problemList.isEmpty()) {
			LOG.error("Adding proof of claim failed with problem(s) for {}, {}, {}, {}", caseID, locationCode, accountNumber, 
					proofOfClaimDTO.getClaimCreationDate());
			throw new C360ValidationException(ErrorUtil.problemToValidationError(problemList));
		}
		proofOfClaim.setDebtor1Id(proofOfClaimDTO.getDebtor1Id());
		proofOfClaim.setDebtor2Id(proofOfClaimDTO.getDebtor2Id());
		return LOG.exit(ProofOfClaimDTO.of(proofOfClaim, modelMapper));
	}
	
	/**
	 * updates a Proof of Claim for an account.
	 * @param proofOfClaimPatch
	 * @param caseID
	 * @param locationCode
	 * @param accountNumber
	 * @param claimCreationDate
	 * @return ProofOfClaimModel
	 */
	@Operation(summary="Update an existing proof of claim",
			description="Updates the details of the proof of claim for the indicated case account."
		)
	@ApiResponses(value = {
		@ApiResponse(responseCode = "200", description = "Successfully updated the proof of claim."),
		@ApiResponse(responseCode = "400", description = "Bad Request")
	})
	@PatchMapping(value = "/cases/{caseID}/accounts/{locationCode}/{accountNumber}/pocs/{claimCreationDate}")
	public ProofOfClaimDTO updateAccountProofOfClaim(@RequestBody JsonPatch proofOfClaimPatch,
			@PathVariable("caseID") String caseID, @PathVariable("locationCode") String locationCode,
			@PathVariable("accountNumber") String accountNumber, @PathVariable("claimCreationDate") String claimCreationDate) {
		LOG.entry(proofOfClaimPatch);
		ProofOfClaim proofOfClaim = (ProofOfClaim) DomainObjectFactory.getInstance().newObject(ProofOfClaim.CLASS_ID);
		proofOfClaim.setCaseID(caseID);
		proofOfClaim.setLocationCode(locationCode);
		proofOfClaim.setAccountNumber(accountNumber);
		Timestamp creationDate = Timestamp.valueOf(LocalDate.parse(claimCreationDate).atStartOfDay());
		proofOfClaim.setClaimCreationDate(creationDate);
		proofOfClaim = (ProofOfClaim) ServiceUtils.loadObjectByBK(proofOfClaim, false);
		if (proofOfClaim == null) {
			LOG.error("proof of claim not found while update for: {}, {}, {}, {}", caseID, locationCode, accountNumber, claimCreationDate);
			Problem problem = (Problem) DomainObjectFactory.getInstance().newObject(Problem.CLASS_ID);
			problem.setErrorSymbol(ProblemNumbers.MSG_NO_RECORDS);
			problem.setDescription("No Proof of Claim Records returned for entered starting key value");
			List<Problem> problemList = new ArrayList<>();
			problemList.add(problem);
			throw new C360ValidationException(ErrorUtil.problemToValidationError(problemList));
		}
		ProofOfClaimDTO proofOfClaimDTO = ProofOfClaimDTO.of(proofOfClaim, modelMapper);
		Set<ConstraintViolation<ProofOfClaimDTO>>  violations = validator.validate(proofOfClaimDTO);
		if(!violations.isEmpty()) {
			LOG.error("Error occured in validating proofOfClaimPatch while update for: {}, {}, {}, {}", caseID, locationCode, accountNumber, 
					claimCreationDate);
			throw new ConstraintViolationException(violations);
		}
		ProofOfClaimDTO pocReqDTO =  ProofOfClaimDTO.of((ProofOfClaim) DomainObjectFactory.getInstance().newObject(ProofOfClaim.CLASS_ID), 
				modelMapper);
		try {
			JsonNode patched = proofOfClaimPatch.apply(objectMapper.convertValue(proofOfClaimDTO, JsonNode.class));
			proofOfClaimDTO = objectMapper.treeToValue(patched, ProofOfClaimDTO.class);
			pocReqDTO = objectMapper.treeToValue(proofOfClaimPatch.apply(objectMapper.convertValue(pocReqDTO, JsonNode.class)),
					ProofOfClaimDTO.class);
		} catch (JsonProcessingException | JsonPatchException ex) {
			LOG.error("Error occured in parsing proofOfClaimPatch for: {}, {}, {}, {}", caseID, locationCode, accountNumber, claimCreationDate);
			throw new C360RuntimeException(ex);
		}
		Assert.isTrue(caseID.equalsIgnoreCase(proofOfClaimDTO.getCaseID()), LOG_INVALID_CASE_ID);
		Assert.isTrue(locationCode.equalsIgnoreCase(proofOfClaimDTO.getLocationCode()), LOG_INVALID_LOCATION_CODE);
		Assert.isTrue(accountNumber.equalsIgnoreCase(proofOfClaimDTO.getAccountNumber()), LOG_INVALID_ACCOUNT_NUMBER);
		Assert.isTrue(creationDate != null && proofOfClaimDTO.getClaimCreationDate() != null && 
				creationDate.compareTo(proofOfClaimDTO.getClaimCreationDate()) == 0 , LOG_INVALID_CLAIM_CREATION_DATE);
		ProofOfClaim pocReq = ProofOfClaimDTO.toDomain(pocReqDTO, modelMapper);
		
		//Validates conditional fields based on the flag 
		BcmProcessingUtils.getInstance().validateConditionalRequiredFields(pocReq);
		
		//Validates fields can be updated only when status is draft
		BcmProcessingUtils.getInstance().validateFieldsBasedOnstatus(pocReq);
		
		List<Problem> fieldProblemList = pocReq.getChildren(Problem.CLASS_ID);
		if (!fieldProblemList.isEmpty()) {
			LOG.error("Updating Proof of Claim failed with problem(s) {}", ProblemUtil.getInstance().extractProblems(proofOfClaim));
			throw new C360ValidationException(ErrorUtil.problemToValidationError(fieldProblemList));
		}
		proofOfClaim = ProofOfClaimDTO.toDomain(proofOfClaimDTO, modelMapper);
		BcmMgmtService bcmService = (BcmMgmtService) ServiceFactory.getInstance().lookup(BcmMgmtService.LOOKUP_NAME);
		proofOfClaim = bcmService.updateProofOfClaim(proofOfClaim);

		List<Problem> problemList = proofOfClaim.getChildren(Problem.CLASS_ID);
		if (!problemList.isEmpty()) {
			LOG.error("Updating proof of claim failed with problem(s) for {}, {}, {}, {}", caseID, locationCode, accountNumber, creationDate);
			throw new C360ValidationException(ErrorUtil.problemToValidationError(problemList));
		}
		proofOfClaim.setDebtor1Id(proofOfClaimDTO.getDebtor1Id());
		proofOfClaim.setDebtor2Id(proofOfClaimDTO.getDebtor2Id());
		return LOG.exit(ProofOfClaimDTO.of(proofOfClaim, modelMapper));
	}
	
	/**
	 * update the contacts details for an caseAccountContact.
	 *
	 * @param caseAccountContactPatch
	 * @param caseID
	 * @param locationCode
	 * @param accountNumber
	 * @param contactID
	 * @return CaseAccountContactDTO
	 * @throws C360Exception 
	 */
	@Operation(summary="Update the case account contact",
			description="Updates the details of the case account contact for the indicated case, account and contactId  with the case account contact provided.")
	@ApiResponses(value = {
		@ApiResponse(responseCode = "200", description = "Case account contact updated successfully."),
		@ApiResponse(responseCode = "400", description = "Bad Request")
	})
	@PatchMapping(value = "/cases/{caseID}/accounts/{locationCode}/{accountNumber}/casecontact/{contactId}", consumes = "application/json-patch+json", produces = MediaType.APPLICATION_JSON_VALUE)
	public CaseAccountContactDTO updateCaseAccountContact(@RequestBody JsonPatch caseAccountContactPatch,
			@PathVariable("caseID") String caseID, @PathVariable("locationCode") String locationCode,
			@PathVariable("accountNumber") String accountNumber, @PathVariable("contactId") String contactId) {
		LOG.entry();
		LOG.debug("Update the CaseAccountContact input: {}, {}, {}", caseID, locationCode, contactId);
		CaseAccountContact caseAccountContact = (CaseAccountContact) DomainObjectFactory.getInstance().newObject(CaseAccountContact.CLASS_ID);
		caseAccountContact.setCaseID(caseID);
		caseAccountContact.setLocationCode(locationCode);
		caseAccountContact.setAccountNumber(accountNumber);
		caseAccountContact.setContactId(contactId);
		caseAccountContact = (CaseAccountContact) ServiceUtils.loadObjectByBK(caseAccountContact, false);
		if (caseAccountContact == null) {
			LOG.error("Case Account Contact not found while update for: {}, {}, {}, {}", caseID, locationCode, accountNumber, contactId);
			Problem problem = (Problem) DomainObjectFactory.getInstance().newObject(Problem.CLASS_ID);
			problem.setErrorSymbol(ProblemNumbers.MSG_NO_RECORDS);
			problem.setDescription("No Case Account Contact Records returned for entered starting key value");
			List<Problem> problemList = new ArrayList<>();
			problemList.add(problem);
			throw new C360ValidationException(ErrorUtil.problemToValidationError(problemList));
		}
		CaseAccountContactDTO caseAccountContactDTO = CaseAccountContactDTO.of(caseAccountContact, modelMapper); 
		try {
			JsonNode patched = caseAccountContactPatch.apply(objectMapper.convertValue(caseAccountContactDTO, JsonNode.class));
			caseAccountContactDTO = objectMapper.treeToValue(patched, CaseAccountContactDTO.class);
		} catch (JsonProcessingException | JsonPatchException ex) {
			throw new C360RuntimeException(ex);
		}
		Assert.isTrue(caseID.equalsIgnoreCase(caseAccountContactDTO.getCaseID()), LOG_INVALID_CASE_ID);
		Assert.isTrue(locationCode.equalsIgnoreCase(caseAccountContactDTO.getLocationCode()), LOG_INVALID_LOCATION_CODE);
		Assert.isTrue(accountNumber.equalsIgnoreCase(caseAccountContactDTO.getAccountNumber()), LOG_INVALID_ACCOUNT_NUMBER);
		Assert.isTrue(contactId.equalsIgnoreCase(caseAccountContactDTO.getContactId()), "Contact Id is invalid");
		Set<ConstraintViolation<CaseAccountContactDTO>>  violations = validator.validate(caseAccountContactDTO);
		if(!violations.isEmpty()) {
			LOG.error("Error occured in validating caseAccountContactPatch while update for: {}, {}, {}, {}", caseID, locationCode, accountNumber, 
					contactId);
			List<Problem> problemList = new ArrayList<>();
			for(ConstraintViolation<CaseAccountContactDTO> constraintViolation : violations) {
				LOG.error("Creating problem for caseAccountContactPatch validation fail for: {}, {}, {}, {}", caseID, locationCode, accountNumber, 
						contactId);
				String errorMsg = constraintViolation.getPropertyPath() + SPACE + constraintViolation.getMessage();
				Problem problem = (Problem) DomainObjectFactory.getInstance().newObject(Problem.CLASS_ID);
				problem.setErrorSymbol(ProblemNumbers.FIELD_IS_REQUIRED);
				problem.setDescription(errorMsg);
				problemList.add(problem);
			}
			throw new C360ValidationException(ErrorUtil.problemToValidationError(problemList));
		}
		CaseAccountContact caseAccountContactPatchedObj = CaseAccountContactDTO.toDomain(caseAccountContactDTO, modelMapper);
		BcmMgmtService bcmService = (BcmMgmtService) ServiceFactory.getInstance().lookup(BcmMgmtService.LOOKUP_NAME);
		caseAccountContact = bcmService.updateCaseAccountContact(caseAccountContactPatchedObj);
		List<Problem> problemList = caseAccountContact.getChildren(Problem.CLASS_ID);
		if (!problemList.isEmpty()) {
			LOG.error("Updating CaseAccountContact failed with problem(s) for {}, {}, {}, {}", caseID, locationCode, accountNumber, contactId);
			throw new C360ValidationException(ErrorUtil.problemToValidationError(problemList));
		}
		return LOG.exit(caseAccountContactDTO.of(caseAccountContact, modelMapper));
	}

	/**
	 * adds the Case Debtor with Contact
	 * @param caseDebtorDTO
	 * @param caseID
	 * @return CaseDebtorDTO
	 */
	@Operation(summary="Add a new case debtor with contact",
			description="Adds the details of the case debtor with contact debtor for the indicated case, debtor and contact  with the contactId's provided.")
	@ApiResponses(value = {
		@ApiResponse(responseCode = "200", description = "Contact debtors added successfully."),
		@ApiResponse(responseCode = "400", description = "Bad Request")
	})
	@PostMapping(value = "/cases/{caseID}/debtors")
	public AddCaseDebtorDTO addCaseDebtorWithContact(@RequestBody AddCaseDebtorDTO addCaseDebtorDto,
			@PathVariable("caseID") String caseID) {
		LOG.entry(addCaseDebtorDto.getCaseID());
		Assert.notNull(addCaseDebtorDto, "CaseDebtor must not null");
		Assert.isTrue(caseID.equalsIgnoreCase(addCaseDebtorDto.getCaseID()), LOG_INVALID_CASE_ID);
		
		CaseDebtor caseDebtorDomainObject = AddCaseDebtorDTO.toDomain(addCaseDebtorDto, modelMapper);
		BcmMgmtService bcmService = (BcmMgmtService) ServiceFactory.getInstance().lookup(BcmMgmtService.LOOKUP_NAME);
		CaseDebtor caseDebtor = bcmService.addCaseDebtorWithContactDebtor(caseDebtorDomainObject);
		List<Problem> problemList = caseDebtor.getChildren(Problem.CLASS_ID);
		if (!problemList.isEmpty()) {
			LOG.error("Processing error for adding Case Debtor: {}", caseID);
			throw new C360ValidationException(ErrorUtil.problemToValidationError(problemList));
		}
		return LOG.exit(addCaseDebtorDto.of(caseDebtor, modelMapper));
	}
	
	/**
	 * Purge bankruptcy case details.
	 * @param bcmModel
	 * @return StatusResponseDTO
	 */
	@Operation(summary="Purge bankruptcy case.",
			description="Purge bankruptcy case and all children.")
	@ApiResponses(value = {
			@ApiResponse(responseCode = "200", description = "Bankruptcy Case purged successfully."),
			@ApiResponse(responseCode = "400", description = "Bad Request")
	})
	@DeleteMapping(value = "/cases/{caseID}")
	public StatusResponseDTO purgeCase(@PathVariable("caseID") String caseID) {
		LOG.entry(caseID);
		Assert.notNull(caseID, "caseID must not be null");
		BcmMgmtService bcmService = (BcmMgmtService) ServiceFactory.getInstance().lookup(BcmMgmtService.LOOKUP_NAME);
		BankruptcyCase bcm = (BankruptcyCase) DomainObjectFactory.getInstance().newObject(BankruptcyCase.CLASS_ID);
		bcm.setCaseID(caseID);
		BooleanObj isPurged = bcmService.purgeCase(bcm);
		List<Problem> problemList = isPurged.getChildren(Problem.CLASS_ID);
		if (!problemList.isEmpty()) {
			LOG.error("Processing error for purging a bankruptcy case for case: {}", caseID);
			throw new C360ValidationException(ErrorUtil.problemToValidationError(problemList));
		}
		return LOG.exit(new StatusResponseDTO(StatusResponseDTO.SUCCESS));
	}
}