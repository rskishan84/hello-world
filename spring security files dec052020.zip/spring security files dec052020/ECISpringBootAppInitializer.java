/** $disclosureStatement$ */
package com.cgi.eci.web.spring.deployment;

import javax.servlet.ServletContext;
import javax.servlet.ServletException;

import org.springframework.web.context.WebApplicationContext;

public interface ECISpringBootAppInitializer extends ECIWebservicesAppInitializer {

	/**
	 * Boot focused startup as the root context of the boot app is not defined yet.
	 * 
	 * @param servletContext
	 * @throws ServletException
	 */
	default void onEciStartup(ServletContext servletContext) throws ServletException {
		LOG.entry(servletContext);
		onEciStartup(servletContext, null);
		LOG.exit();
	}

	/**
	 * Registers the ContextLoaderListener with the ServletContext. Overrides the
	 * default implementation to use a SharedContextAwareContextLoaderListener
	 * instead of a simple
	 * 
	 * @param servletContext
	 * @see org.springframework.web.context.AbstractContextLoaderInitializer#registerContextLoaderListener(javax.servlet.ServletContext)
	 */
	@Override
	default void registerSharedContextLoaderListener(ServletContext servletContext,
			WebApplicationContext rootAppContext) {
		LOG.entry(servletContext, rootAppContext);
		SharedContextAwareContextLoaderListener listener = new SharedBootContextAwareContextLoaderListener(
				servletContext);
		listener.setContextInitializers(getRootApplicationContextInitializers());
		servletContext.addListener(listener);
		LOG.exit();
	}
}
