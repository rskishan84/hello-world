/** $disclosureStatement$ */
package com.cgi.ec.restful.dto.bcm;

import java.sql.Timestamp;

import javax.validation.constraints.NotBlank;
import javax.validation.constraints.NotNull;
import javax.validation.constraints.Size;

import org.modelmapper.ModelMapper;
import org.slf4j.ext.XLogger;
import org.slf4j.ext.XLoggerFactory;

import com.ams.core.util.DomainObjectFactory;
import com.cgi.ec.domain.bcm.ContactDebtor;
import com.cgi.ec.util.DateDeserialization;
import com.cgi.ec.util.DateSerialization;
import com.fasterxml.jackson.databind.annotation.JsonDeserialize;
import com.fasterxml.jackson.databind.annotation.JsonSerialize;

import io.swagger.v3.oas.annotations.media.Schema;
import lombok.AccessLevel;
import lombok.AllArgsConstructor;
import lombok.Data;
import lombok.NoArgsConstructor;

/**
 * 
 * DTO for the Contact Debtor domain, providing the public interface for the 
 * domain object.
 *
 */
@AllArgsConstructor(staticName = "of")
@NoArgsConstructor(access=AccessLevel.PROTECTED)
@Data
public class ContactDebtorDTO {
	private static final XLogger LOG = XLoggerFactory.getXLogger(ContactDebtorDTO.class);
	
	@Size(min=10, max=10)
	@Schema(description="Unique identifier for the case. Concatenated value of Court District and Case Number "
			+ "of the Bankruptcy Case where Case Number is the concatenation of filing year and filing sequence number.",
			required=true,
			example="ALS2011111")
	private String caseID;
	
	@NotNull
	@NotBlank
	@Size(max=24)
	@Schema(description="Contact ID of the CACS contacts.",
			required=true)
	private String contactID;
	
	@Size(max=8)
	@Schema(description="UserID of the last user to perform a Save Action against this instance.")
	private String lastUpdateUser;
	
	@Schema(description="The last update date time stamp to perform a Save Action against this instance.",
			example="2014-12-29T13:46:18.000+0000")
	@JsonDeserialize(using = DateDeserialization.class)
	@JsonSerialize(using = DateSerialization.class)
	private Timestamp lastUpdateDateTimeStamp;
	
	/**
	 * model to domain mapping
	 * @param ContactDebtorDTO
	 * @param ModelMapper 
	 * @return domain
	 */
	public static ContactDebtor toDomain(ContactDebtorDTO dto, ModelMapper modelMapper) {
		LOG.entry(dto);
		ContactDebtor domain = (ContactDebtor) DomainObjectFactory.getInstance().newObject(ContactDebtor.CLASS_ID);
		modelMapper.map(dto, domain);		
		return LOG.exit(domain);
	}
	
	/**
	 * domain to model mapping
	 * @param ContactDebtor
	 * @param ModelMapper 
	 * @return dto
	 */
	public static ContactDebtorDTO of(ContactDebtor domain, ModelMapper modelMapper) {
		LOG.entry(domain);
		ContactDebtorDTO dto = modelMapper.map(domain, ContactDebtorDTO.class);
		return LOG.exit(dto);
	}
}