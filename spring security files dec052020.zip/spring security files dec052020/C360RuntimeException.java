/** $disclosureStatement$ */
package com.cgi.c360.exception;

/**
 * Common exception that should be the parent of all runtime exceptions 
 * within the C360 applications.
 *
 */
public class C360RuntimeException extends RuntimeException {

	/**
	 * Default SerialVersionUID
	 */
	private static final long serialVersionUID = 1L;
	
	public C360RuntimeException() {
		super();
	}

	public C360RuntimeException(String message, Throwable cause, boolean enableSuppression,
			boolean writableStackTrace) {
		super(message, cause, enableSuppression, writableStackTrace);
	}

	public C360RuntimeException(String message, Throwable cause) {
		super(message, cause);
	}

	public C360RuntimeException(String message) {
		super(message);
	}

	public C360RuntimeException(Throwable cause) {
		super(cause);
	}

}
