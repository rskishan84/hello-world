/** $disclosureStatement$ */
package com.cgi.c360.exception;

/**
 * Common exception that should be the parent of all checked exceptions 
 * within the C360 applications.
 *
 */
public class C360Exception extends Exception {

	/**
	 * Default SerialVersionUID
	 */
	private static final long serialVersionUID = 1L;

	public C360Exception() {
		super();
	}

	public C360Exception(String message, Throwable cause, boolean enableSuppression,
			boolean writableStackTrace) {
		super(message, cause, enableSuppression, writableStackTrace);
	}

	public C360Exception(String message, Throwable cause) {
		super(message, cause);
	}

	public C360Exception(String message) {
		super(message);
	}

	public C360Exception(Throwable cause) {
		super(cause);
	}
	
}
