/** $disclosureStatement$ */
package com.cgi.ec.restful.config;


import java.util.Arrays;

import org.slf4j.ext.XLogger;
import org.slf4j.ext.XLoggerFactory;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.beans.factory.annotation.Value;
import org.springframework.context.annotation.Bean;
import org.springframework.http.HttpMethod;
import org.springframework.security.authentication.AuthenticationEventPublisher;
import org.springframework.security.authentication.AuthenticationManager;
import org.springframework.security.authentication.jaas.AuthorityGranter;
import org.springframework.security.config.annotation.authentication.builders.AuthenticationManagerBuilder;
import org.springframework.security.config.annotation.web.builders.HttpSecurity;
import org.springframework.security.config.annotation.web.configuration.EnableWebSecurity;
import org.springframework.security.config.annotation.web.configuration.WebSecurityConfigurerAdapter;
import org.springframework.security.web.authentication.logout.SimpleUrlLogoutSuccessHandler;
import org.springframework.security.web.jaasapi.JaasApiIntegrationFilter;
import org.springframework.web.cors.CorsConfiguration;

import com.cgi.eci.spring.properties.RuntimeProperties;
import com.cgi.eci.spring.security.DelegateAuthenticationProvider;
import com.cgi.eci.spring.security.ECIJaasSubjectBridgeFilter;
import com.cgi.eci.spring.security.impl.RoleUserAuthorityGranter;

/**
 * CACS application web security java configuration replicating ECI setup to avoid the configuration of the ECI*SecurityConfig classes
 */
@EnableWebSecurity
public class CACSRestServiceSecurityConfig extends WebSecurityConfigurerAdapter {

	/** XLogger. */
	private static final XLogger LOG = XLoggerFactory.getXLogger(CACSRestServiceSecurityConfig.class);
	@Value("${cors.allowedorigins}")
	private String[] corsAllowedOrigins;
	@Value("${cors.allowedmethods}")
	private String[] allowedMethods;
	@Value("${cors.allowedheaders}")
	private String[] allowedHeaders;
	/** The runtime properties */
	@Autowired
	RuntimeProperties runtimeProperties;

	/**
	 * CACS Rest security configuration.
	 *
	 * @param http the http
	 * @throws Exception the exception
	 * @see org.springframework.security.config.annotation.web.configuration.WebSecurityConfigurerAdapter#configure(org.springframework.security.config.annotation.web.builders.HttpSecurity)
	 */
	@Override
	protected void configure(HttpSecurity http) throws Exception {
		LOG.entry(http);

		// configure error handling
		LOG.info("Config: REST Services HTTP Security configuration started.");
		http.addFilterAfter(new ECIJaasSubjectBridgeFilter(), JaasApiIntegrationFilter.class);
		// Enable cors  on the REST Services application
		CorsConfiguration configuration = new CorsConfiguration();
		configuration.setAllowedMethods(Arrays.asList(HttpMethod.PUT.name(),HttpMethod.POST.name(),HttpMethod.DELETE.name(),HttpMethod.GET.name()));
		http.cors().configurationSource(request -> configuration.applyPermitDefaultValues());
		// Enable basic authentication on the REST Services application
		LOG.info("Config: REST Services HTTP Security enable basic http authentication.");
        http.authorizeRequests().anyRequest().authenticated().and().httpBasic().and().csrf().disable();
		LOG.info("Config: REST Services HTTP Security configuration complete.");
		LOG.exit();
	}

	/**
	 * Configures global security.
	 *
	 * @param auth
	 */
	@Autowired
	protected void configureGlobal(AuthenticationManagerBuilder auth,
			DelegateAuthenticationProvider delegateAuthenticationProvider,
			AuthenticationEventPublisher authenticationEventPublisher) {
		LOG.entry(auth);
		auth.authenticationProvider(delegateAuthenticationProvider);
		auth.authenticationEventPublisher(authenticationEventPublisher);

		LOG.exit();
	}

	/**
	 * Returns the Authority Granter.
	 *
	 * @return
	 */
	@Bean
	protected AuthorityGranter authorityGranter() {
		LOG.entry();
		return LOG.exit(new RoleUserAuthorityGranter());
	}

	@Override
	@Bean(name = "restbServicesAuthenticationManagerBean")
	public AuthenticationManager authenticationManagerBean() throws Exception {
		return super.authenticationManagerBean();
	}

	// Handler for successful logout
	@Bean
	public SimpleUrlLogoutSuccessHandler successLogoutHandler() {
		SimpleUrlLogoutSuccessHandler successLogoutHandler = new SimpleUrlLogoutSuccessHandler();
		LOG.info("Config: Creating LogoutSuccessHandler: " + SimpleUrlLogoutSuccessHandler.class.getName());
		successLogoutHandler.setDefaultTargetUrl("/logoutSuccess");
		return successLogoutHandler;
	}

}