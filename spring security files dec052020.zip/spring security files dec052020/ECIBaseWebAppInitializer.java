/** $disclosureStatement$ */
package com.cgi.eci.web.spring.deployment;

import java.io.IOException;
import java.io.InputStream;
import java.util.EnumSet;
import java.util.Properties;

import javax.servlet.ServletContext;
import javax.servlet.ServletException;
import javax.servlet.SessionTrackingMode;

import org.slf4j.ext.XLogger;
import org.slf4j.ext.XLoggerFactory;
import org.springframework.context.ApplicationContextInitializer;
import org.springframework.context.annotation.Bean;
import org.springframework.core.io.ClassPathResource;
import org.springframework.security.web.session.HttpSessionEventPublisher;
import org.springframework.web.context.WebApplicationContext;
import org.springframework.web.servlet.DispatcherServlet;

import com.cgi.eci.spring.properties.AppRuntimeProperties;
import com.cgi.eci.spring.util.Constants;

public interface ECIBaseWebAppInitializer {
	
	static final XLogger LOG = XLoggerFactory.getXLogger(ECIBaseWebAppInitializer.class);

	/**
	 * Configures the current ServletContext. Initializes the application.
	 *
	 * @param servletContext the servlet context
	 * @throws ServletException the servlet exception
	 * @see org.springframework.web.servlet.support.AbstractDispatcherServletInitializer#onStartup(javax.servlet.ServletContext)
	 */
	default void onEciStartup(ServletContext servletContext, WebApplicationContext rootAppContext) throws ServletException {
		LOG.entry(servletContext);
		
		Properties props = loadInitializationProperties();
		servletContext.addListener(new HttpSessionEventPublisher());
		registerSharedContextLoaderListener(servletContext, rootAppContext);
		configCookieSettings(servletContext, props);
		configServlets(servletContext, props);
		configRequestFilters(servletContext, props);
		configListeners(servletContext, props);

		LOG.exit();
	}

	/**
	 * Registers the ContextLoaderListener with the ServletContext. Overrides the
	 * default implementation to use a SharedContextAwareContextLoaderListener
	 * instead of a simple
	 * 
	 * @param servletContext
	 * @see org.springframework.web.context.AbstractContextLoaderInitializer#registerContextLoaderListener(javax.servlet.ServletContext)
	 */
	default void registerSharedContextLoaderListener(ServletContext servletContext, WebApplicationContext rootAppContext) {
		if (rootAppContext != null) {
			SharedContextAwareContextLoaderListener listener = new SharedContextAwareContextLoaderListener(
					rootAppContext);
			listener.setContextInitializers(getRootApplicationContextInitializers());
			servletContext.addListener(listener);
		} else {
			LOG.debug("No ContextLoaderListener registered, as "
					+ "createRootApplicationContext() did not return an application context");
		}
	}

	/**
	 * Return any app context initializers needed.
	 * @return initializers
	 */
	default ApplicationContextInitializer<?>[] getRootApplicationContextInitializers() {
		return null;
	}
	
	/**
	 * Initialize dispatcher servlet
	 * @return
	 */
	@Bean
	default DispatcherServlet dispatcherServlet(WebApplicationContext rootContext) {
	    DispatcherServlet dispatcherServlet = new DispatcherServlet(rootContext);
	    dispatcherServlet.setThrowExceptionIfNoHandlerFound(true);
	    return dispatcherServlet;
	}

	/**
	 * Loads the initialization properties files for the web app. After
	 * initialization these \ properties will be available via a class but at the
	 * current point in the process Spring has not completed loading Bean instances.
	 * So we must use standard java practices to load the file.
	 * 
	 * @return The initialization properties.
	 * @throws ServletException
	 */
	default Properties loadInitializationProperties() throws ServletException {
		LOG.entry();
		Properties appInitProps = new Properties();
		LOG.info("Loading Initialization Properties from resource on classpath location {}",
				AppRuntimeProperties.getAppRuntimePropsFilename());
		try {
			
			InputStream propsStream = new ClassPathResource(AppRuntimeProperties.getAppRuntimePropsFilename())
					.getInputStream();
			appInitProps.load(propsStream);

		} catch (IOException ioe) {
			String errorDesc = "Unable to load properties from " + AppRuntimeProperties.getAppRuntimePropsFilename();
			LOG.error(errorDesc, ioe);
			throw new ServletException(errorDesc, ioe);
		}
		return LOG.exit(appInitProps);
	}

	/**
	 * Configures the cookie settings for the WebApp
	 * 
	 * @param servletContext
	 * @param props          This string may be use for further computation in
	 *                       overriding classes
	 * 
	 */
	default void configCookieSettings(ServletContext servletContext, Properties props) {
		String contextPath = servletContext.getContextPath();
		// Prepend a "/" to the context path if one is not already there.
		contextPath = contextPath.startsWith(Constants.FORWARD_SLASH) ? contextPath
				: Constants.FORWARD_SLASH + contextPath;
		servletContext.getSessionCookieConfig().setPath(contextPath);
		servletContext.getSessionCookieConfig().setHttpOnly(true);
		servletContext.getSessionCookieConfig().setSecure(Boolean.valueOf(props.getProperty("sessionCookieSecureFlag")));
		servletContext.setSessionTrackingModes(EnumSet.of(SessionTrackingMode.COOKIE));
	}

	/**
	 * Configures the request filters for the Web Application.
	 * 
	 * @param servletContext
	 * @param props
	 */
	abstract void configRequestFilters(ServletContext servletContext, Properties props);

	/**
	 * Configures the baseline servlets for an ECI Baseed Web Application.
	 * 
	 * @param servletContext
	 * @param appInitProperties
	 */
	abstract void configServlets(ServletContext servletContext, Properties props);

	/**
	 * Configures the listeners for an ECI Baseed Web Application.
	 * 
	 * @param servletContext
	 * @param appInitProperties
	 */
	abstract void configListeners(ServletContext servletContext, Properties props);
}
