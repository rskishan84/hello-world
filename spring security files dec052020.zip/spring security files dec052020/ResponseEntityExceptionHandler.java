/** $disclosureStatement$ */
package com.cgi.ec.restful;

import org.springframework.web.bind.annotation.ControllerAdvice;

import com.cgi.c360.exception.RestResponseEntityExceptionHandler;

/**
 * Custom Exception handler for the CACS application.
 */
@ControllerAdvice
public class ResponseEntityExceptionHandler extends RestResponseEntityExceptionHandler {

}
