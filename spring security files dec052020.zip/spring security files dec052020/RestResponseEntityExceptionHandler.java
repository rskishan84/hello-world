/** $disclosureStatement$ */
package com.cgi.c360.exception;

import java.util.HashMap;
import java.util.Map;

import org.springframework.http.HttpHeaders;
import org.springframework.http.HttpStatus;
import org.springframework.http.ResponseEntity;
import org.springframework.http.converter.HttpMessageNotReadableException;
import org.springframework.validation.FieldError;
import org.springframework.web.bind.MethodArgumentNotValidException;
import org.springframework.web.bind.annotation.ControllerAdvice;
import org.springframework.web.bind.annotation.ExceptionHandler;
import org.springframework.web.bind.annotation.ResponseStatus;
import org.springframework.web.context.request.WebRequest;
import org.springframework.web.servlet.mvc.method.annotation.ResponseEntityExceptionHandler;

/**
 * A convenient base class for {@link ControllerAdvice @ControllerAdvice} classes
 * that wish to provide centralized exception handling across all
 * {@code @RequestMapping} methods through {@code @ExceptionHandler} methods.
 *
 *
 * Currently an empty implementation used as a place holder if additional
 * processing is necessary.  For REST services the basic handling provides
 * the details in the format we would like.
 */
public abstract class RestResponseEntityExceptionHandler extends ResponseEntityExceptionHandler {
 
	/**
	 * Handler for a C360ValidationException
	 * @param ex
	 * @param request
	 * @return
	 */
	@ExceptionHandler(C360ValidationException.class)
	@ResponseStatus(HttpStatus.BAD_REQUEST)	
	protected ResponseEntity<Object> handleValidationException(
			C360ValidationException ex, WebRequest request) {
			
		 return ResponseEntity.badRequest().body(ex.getErrors());
	}
		
	/**
	 * Handler for a C360ValidationException.
	 * @param ex
	 * @param request
	 * @return
	 */
	@Override
	@ResponseStatus(HttpStatus.BAD_REQUEST)	
	protected ResponseEntity<Object> handleMethodArgumentNotValid(
			MethodArgumentNotValidException ex, HttpHeaders headers, HttpStatus status, WebRequest request) {
		Map<String,String> errors = new HashMap<>();
		ex.getBindingResult().getAllErrors().forEach(error -> {
			String fieldName = ((FieldError) error).getField();
			String errorMessage = error.getDefaultMessage();
			errors.put(fieldName, errorMessage);
		});
		
		C360ValidationError validationErrors = C360ValidationError.builder()
				.status(HttpStatus.BAD_REQUEST)
				.addErrors(errors).build();
		
		 return ResponseEntity.badRequest().body(validationErrors);
	}
	
	
	/**
	 * Customize the response for HttpMessageNotReadableException.
	 * <p>This method delegates to {@link #handleExceptionInternal}.
	 * @param ex the exception
	 * @param headers the headers to be written to the response
	 * @param status the selected response status
	 * @param request the current request
	 * @return a {@code ResponseEntity} instance
	 */
	@Override
	@ResponseStatus(HttpStatus.BAD_REQUEST)	
	protected ResponseEntity<Object> handleHttpMessageNotReadable(
			HttpMessageNotReadableException ex, HttpHeaders headers, HttpStatus status, WebRequest request) {

		Map<String,String> errors = new HashMap<>();
		errors.put("Message Not Readable", ex.getMessage());
	
		C360ValidationError validationErrors = C360ValidationError.builder()
				.status(HttpStatus.BAD_REQUEST)
			 	.addError("Message Not Readable", ex.getMessage())
			 	.build();
		
		 return ResponseEntity.badRequest().body(validationErrors);
	}
	
}
