/** $disclosureStatement$ */
package com.cgi.c360.exception;

import java.io.Serializable;
import java.util.ArrayList;
import java.util.List;
import java.util.Map;

import org.springframework.http.HttpStatus;

import lombok.AllArgsConstructor;
import lombok.Builder;
import lombok.Value;

@Value
@Builder
public class C360ValidationError implements Serializable {

	private static final long serialVersionUID = 1L;

	@Builder.Default
	private HttpStatus status = HttpStatus.BAD_REQUEST;
	
	private List<Error> errors;	
	
	
	public void addError(String message, String description) {
		errors.add(new Error(message, description));
	}
	
	@Value
	@AllArgsConstructor
	private static class Error implements Serializable{
		private static final long serialVersionUID = 1L;
		String message;
		String description;
	}
	
	public static class C360ValidationErrorBuilder{
		public C360ValidationErrorBuilder addError(String message, String description) {
			errors = errors == null ? new ArrayList<>() : errors;
			errors.add(new C360ValidationError.Error(message, description));
			return this;
		}
		
		public C360ValidationErrorBuilder addErrors(Map<String,String> newErrors) {
			for( Map.Entry<String,String> entry : newErrors.entrySet() ) {				
				addError(entry.getKey(), entry.getValue());
			}
			return this;
		}
	}
}
