/** $disclosureStatement$ */
package com.cgi.c360.exception;

import org.springframework.http.HttpStatus;
import org.springframework.web.bind.annotation.ResponseStatus;

@ResponseStatus(HttpStatus.BAD_REQUEST)
public class C360ValidationException extends C360RuntimeException{

	/**
	 * Default Serial UID
	 */
	private static final long serialVersionUID = 1L;

	private static final String DEFAULT_MESSAGE = "Validation Error";
	
	private final C360ValidationError errors;

	public C360ValidationException(C360ValidationError errors) {
		super(DEFAULT_MESSAGE);
		this.errors = errors;
	}
	
	public C360ValidationException(String message, String description) {
		super(DEFAULT_MESSAGE);
		this.errors = C360ValidationError.builder().addError(message, description).build();
	}
	
	public void addError(String message, String description) {
		this.getErrors().addError(message, description);
	}
	
	public C360ValidationError getErrors() {
		return errors;
	}
	
	
}
