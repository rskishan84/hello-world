/** $disclosureStatement$ */
package com.cgi.ec.restful;

import javax.servlet.ServletContext;
import javax.servlet.ServletException;

import org.modelmapper.ModelMapper;
import org.modelmapper.PropertyMap;
import org.modelmapper.convention.MatchingStrategies;
import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;
import org.springframework.boot.builder.SpringApplicationBuilder;
import org.springframework.boot.web.servlet.support.SpringBootServletInitializer;
import org.springframework.context.annotation.Bean;

import com.cgi.ec.domain.bcm.BankruptcyCase;
import com.cgi.ec.domain.caseprocessing.Bankruptcy;
import com.cgi.ec.restful.dto.bcm.BankruptcyCaseDTO;
import com.cgi.ec.restful.dto.coll.contacts.BankruptcyDTO;
import com.cgi.eci.web.spring.deployment.ECISpringBootAppInitializer;

/**
 * CACS REST API boot application.
 */
@SpringBootApplication
public class CacsRestServiceApplication extends SpringBootServletInitializer implements ECISpringBootAppInitializer {

	/**
	 * JVM main boot startup
	 * @param args
	 */
	public static void main(String[] args) {
        SpringApplication.run(CacsRestServiceApplication.class, args);
	}
	
	/**
	 * Boot configuration class assignment
	 */
	@Override
	protected SpringApplicationBuilder configure(SpringApplicationBuilder application) {
		return application.sources(CacsRestServiceApplication.class);
	}
	
	@Bean
	public ModelMapper modelMapper() {
		ModelMapper modelMapper = new ModelMapper();
		modelMapper.getConfiguration().setAmbiguityIgnored(true);
		modelMapper.getConfiguration().setFullTypeMatchingRequired(true);
		modelMapper.getConfiguration().setMatchingStrategy(MatchingStrategies.STRICT);		
		
		PropertyMap<BankruptcyCaseDTO, BankruptcyCase> bankruptcyCaseSkipFieldsMap = new PropertyMap<BankruptcyCaseDTO, BankruptcyCase>() {
			protected void configure() {
				skip().setStatus(null);
			}
		};
		
		PropertyMap<BankruptcyDTO, Bankruptcy> bankruptcySkipFieldsMap = new PropertyMap<BankruptcyDTO, Bankruptcy>() {
			protected void configure() {
				skip().setStatus(null);
			}
		};
		
		modelMapper.addMappings(bankruptcyCaseSkipFieldsMap);
		modelMapper.addMappings(bankruptcySkipFieldsMap);
		
		return modelMapper;
	}
	
	/**
	 * ECI Spring Boot startup override.
	 */
	@Override
	public void onStartup(ServletContext servletContext) throws ServletException {

		onEciStartup(servletContext);
		super.onStartup(servletContext);
	}
		
}
