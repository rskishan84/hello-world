/** $disclosureStatement$ */
package com.cgi.ec.restful;

import io.swagger.v3.oas.annotations.OpenAPIDefinition;
import io.swagger.v3.oas.annotations.info.Contact;
import io.swagger.v3.oas.annotations.info.Info;

@OpenAPIDefinition(
  info = @Info(
	  title = "CACS Rest Service Portal",
	  description = "CACS Rest Service Portal",
	  contact = @Contact(
	    name = "CACS Rest Service", 
	    url = "http://www.cgi.com", 
	    email = "collections.support@cgi.com"
	  )
  )
)
public class OpenAPIConfiguration {

}
