/** $disclosureStatement$ */
package com.cgi.eci.web.spring.deployment;

import javax.servlet.ServletContext;
import javax.servlet.ServletContextEvent;

import org.springframework.web.context.WebApplicationContext;

public class SharedBootContextAwareContextLoaderListener extends SharedContextAwareContextLoaderListener {

	/**
	 * Maps the ECI shared context for boot initialization.
	 * SpringBootServletInitializer looks for parent context if set in the
	 * servletContext.
	 * 
	 * @param servletContext
	 */
	public SharedBootContextAwareContextLoaderListener(ServletContext servletContext) {
		super();
		servletContext.setAttribute(WebApplicationContext.ROOT_WEB_APPLICATION_CONTEXT_ATTRIBUTE,
				loadParentContext(servletContext));
	}

	/**
	 * Noop to fit with the boot initialization sequences, hint taken from
	 * SpringBootServletInitializer
	 */
	@Override
	public void contextInitialized(ServletContextEvent event) {
		// do nothing as boot as already initialized the context.
	}
}
