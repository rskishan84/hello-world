/** $disclosureStatement$ */
package com.cgi.eci.web.spring.deployment;

import java.util.EnumSet;
import java.util.Properties;

import javax.servlet.DispatcherType;
import javax.servlet.FilterRegistration;
import javax.servlet.ServletContext;

import org.slf4j.ext.XLogger;
import org.slf4j.ext.XLoggerFactory;
import org.springframework.web.filter.RequestContextFilter;

import com.ams.core.ui.filters.ClientIPAddressFilter;
import com.ams.core.ui.filters.SessionFilter;

public interface ECIWebservicesAppInitializer extends ECIBaseWebAppInitializer {
	
	static final XLogger LOG = XLoggerFactory.getXLogger(ECIWebservicesAppInitializer.class);
		
	/**
	 * Defines the Servlet config classes. Currently none are defined.
	 *
	 * @return the servlet config classes
	 * @see org.springframework.web.servlet.support.AbstractAnnotationConfigDispatcherServletInitializer#getServletConfigClasses()
	 */
	default Class<?>[] getServletConfigClasses() {
		LOG.entry();
		return LOG.exit(new Class[] {});
	}

	/**
	 * Returns the default servlet mappings.
	 *
	 * @return the servlet mappings
	 * @see org.springframework.web.servlet.support.AbstractDispatcherServletInitializer#getServletMappings()
	 */
	default String[] getServletMappings() {
		LOG.entry();
		return LOG.exit(new String[] { "/" });
	}

	/**
	 * Configures the request filters for the Web Application.
	 * 
	 * @param servletContext
	 * @param props
	 */
	default void configRequestFilters(ServletContext servletContext, Properties props) {
		LOG.entry(servletContext, props);
		// Add the baseline filters.
		if (!Boolean.FALSE.toString().equalsIgnoreCase(props.getProperty("enableRequestContextFilter_WS"))) {
			LOG.info("Adding requestContextFilter Servlet Filter to WebApp configuration");
			FilterRegistration.Dynamic requestContextFilter = servletContext.addFilter("requestContextFilter",
					RequestContextFilter.class);
			
			if( requestContextFilter != null ) {
				requestContextFilter.addMappingForUrlPatterns(EnumSet.of(DispatcherType.REQUEST, DispatcherType.FORWARD,
						DispatcherType.INCLUDE, DispatcherType.ASYNC), false, "/*");
			}
		} else {
			LOG.info("Omitting requestContextFilter Servlet Filter from WebServices WebApp configuration");
		}

		if (!Boolean.FALSE.toString().equalsIgnoreCase(props.getProperty("enableClientIPAddressFilter_WS"))) {
			LOG.info("Adding ClientIPAddressFilter Servlet Filter to WebApp configuration");
			FilterRegistration.Dynamic clientIPAddressFilter = servletContext.addFilter("ClientIPAddressFilter",
					ClientIPAddressFilter.class);
			if( clientIPAddressFilter != null ) {
				clientIPAddressFilter.addMappingForUrlPatterns(EnumSet.of(DispatcherType.REQUEST, DispatcherType.FORWARD,
						DispatcherType.INCLUDE, DispatcherType.ASYNC), true, "/*");
			}
		} else {
			LOG.info("Omitting ClientIPAddressFilter Servlet Filter from WebServices WebApp configuration");
		}

		if (!Boolean.FALSE.toString().equalsIgnoreCase(props.getProperty("enableSessionFilter_WS"))) {
			LOG.info("Adding SessionFilter Servlet Filter to WebApp configuration");
			FilterRegistration.Dynamic sessionFilter = servletContext.addFilter("SessionFilter", SessionFilter.class);
			if( sessionFilter != null ) {
				sessionFilter.setInitParameter("debug", props.getProperty("sessionFilterDebugFlag_WS"));
				sessionFilter.addMappingForUrlPatterns(EnumSet.of(DispatcherType.REQUEST, DispatcherType.FORWARD,
						DispatcherType.INCLUDE, DispatcherType.ASYNC), true, "/*");
			}
		} else {
			LOG.info("Omitting SessionFilter Servlet Filter from WebServices WebApp configuration");
		}
		LOG.exit();
	}
	
	/**
	 * Configures the baseline servlets for an ECI Baseed Web Application.
	 *
	 * @param servletContext
	 * @param appInitProperties
	 */
	default void configServlets(ServletContext servletContext, Properties props) {
		LOG.entry(servletContext, props);
		LOG.exit();
	}

	/**
	 * Used to configure listeners in the servlet Context.
	 * 
	 * @param servletContext
	 * @param props
	 * @see com.cgi.eci.web.spring.deployment.AbstractECIBaseWebAppInitializer#configListeners(javax.servlet.ServletContext,
	 *      java.util.Properties)
	 */
	default void configListeners(ServletContext servletContext, Properties props) {
		// NoOp at this level.
	}

	/**
	 * Overrides the dispatcher servlet name so it doesn't conflict with the main
	 * web app.
	 * 
	 * @return
	 * @see org.springframework.web.servlet.support.AbstractDispatcherServletInitializer#getServletName()
	 */
	default String getServletName() {
		LOG.entry();
		return LOG.exit("wsDispatcher");
	}

}